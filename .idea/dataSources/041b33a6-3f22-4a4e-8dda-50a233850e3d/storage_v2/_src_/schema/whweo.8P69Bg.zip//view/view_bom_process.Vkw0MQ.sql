create view view_bom_process as
  select
    `bp`.`id`                         AS `id`,
    `bp`.`bom_id`                     AS `bom_id`,
    `bp`.`show_order`                 AS `show_order`,
    `bp`.`process_id`                 AS `process_id`,
    `bp`.`process_code`               AS `process_code`,
    `p`.`process_name`                AS `process_name`,
    `p`.`process_type_id`             AS `process_type_id`,
    `bp`.`after_code`                 AS `after_code`,
    `bp`.`check_type_id`              AS `check_type_id`,
    `c`.`type_code`                   AS `check_type_code`,
    `c`.`type_name`                   AS `check_type`,
    `bp`.`output_material_code`       AS `output_material_code`,
    `m`.`material_name`               AS `output_material_name`,
    `bp`.`output_material_status_int` AS `output_material_status_int`,
    `bp`.`output_material_status_str` AS `output_material_status_str`,
    `bp`.`complete_process_code`      AS `complete_process_code`,
    `bp`.`modifier_code`              AS `modifier_code`,
    `bp`.`modifier_name`              AS `modifier_name`,
    `bp`.`gmt_modified`               AS `gmt_modified`,
    `bp`.`gmt_create`                 AS `gmt_create`
  from (((`whweo`.`bdp_bom_process` `bp` left join `whweo`.`bdp_process` `p`
      on ((`bp`.`process_code` = `p`.`process_code`))) left join `whweo`.`bdp_material` `m`
      on ((`bp`.`output_material_code` = `m`.`material_code`))) left join `whweo`.`qc_check_type` `c`
      on ((`bp`.`check_type_id` = `c`.`id`)));

