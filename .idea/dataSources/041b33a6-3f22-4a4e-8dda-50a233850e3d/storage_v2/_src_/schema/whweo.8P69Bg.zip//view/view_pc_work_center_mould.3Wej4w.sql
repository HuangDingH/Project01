create view view_pc_work_center_mould as
  select
    `a`.`id`                 AS `id`,
    `a`.`bom_id`             AS `bom_id`,
    `a`.`process_id`         AS `process_id`,
    `a`.`efficiency`         AS `efficiency`,
    `a`.`efficiency_unit`    AS `efficiency_unit`,
    `a`.`version`            AS `version`,
    `a`.`is_default_version` AS `is_default_version`,
    `b`.`id`                 AS `work_center_id`,
    `b`.`work_center_code`   AS `work_center_code`,
    `b`.`work_center_name`   AS `work_center_name`,
    `c`.`id`                 AS `mould_id`,
    `c`.`mould_code`         AS `mould_code`,
    `c`.`mould_name`         AS `mould_name`
  from ((`whweo`.`bdp_bom_process_efficiency` `a` left join `whweo`.`bdp_work_center` `b`
      on ((`a`.`work_center_id` = `b`.`id`))) left join `whweo`.`mj_mould_ledger` `c` on ((`a`.`mould_id` = `c`.`id`)));

