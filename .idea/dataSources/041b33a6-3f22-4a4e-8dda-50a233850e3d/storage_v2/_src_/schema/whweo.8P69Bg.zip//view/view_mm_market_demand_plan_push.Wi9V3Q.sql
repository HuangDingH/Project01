create view view_mm_market_demand_plan_push as
  select
    `a`.`product_code`                                                                                          AS `product_code`,
    `a`.`product_name`                                                                                          AS `product_name`,
    `a`.`specification_type`                                                                                    AS `specification_type`,
    `a`.`serial_number`                                                                                         AS `serial_number`,
    `a`.`special_requirement`                                                                                   AS `special_requirement`,
    `a`.`base_unit_name`                                                                                        AS `base_unit_name`,
    `a`.`suggest_delivery_date`                                                                                 AS `suggest_delivery_date`,
    `a`.`detail_requirements`                                                                                   AS `detail_requirements`,
    `a`.`note`                                                                                                  AS `note`,
    `a`.`push_down_number`                                                                                      AS `push_down_number`,
    `a`.`total_num`                                                                                             AS `total_num`,
    ifnull(sum(`b`.`inventory_quantity`),
           0)                                                                                                   AS `product_store_num`,
    ifnull(`c`.`safety_amount`,
           0)                                                                                                   AS `safety_amount`,
    (ifnull(sum(`d`.`production_amount`), 0) - ifnull(sum(`e`.`inventory_quantity`),
                                                      0))                                                       AS `online_inventory`,
    ifnull(sum(`f`.`actual_shipment_amount`),
           0)                                                                                                   AS `undelivered_quantity`,
    if(((((((`a`.`total_num` - ifnull(sum(`b`.`inventory_quantity`), 0)) + ifnull(`c`.`safety_amount`, 0)) -
           ifnull(sum(`d`.`production_amount`), 0)) + ifnull(sum(`e`.`inventory_quantity`), 0)) +
         ifnull(sum(`f`.`actual_shipment_amount`), 0)) < 0), 0, (((((`a`.`total_num` -
                                                                     ifnull(sum(`b`.`inventory_quantity`), 0)) +
                                                                    ifnull(`c`.`safety_amount`, 0)) -
                                                                   ifnull(sum(`d`.`production_amount`), 0)) +
                                                                  ifnull(sum(`e`.`inventory_quantity`), 0)) +
                                                                 ifnull(sum(`f`.`actual_shipment_amount`),
                                                                        0)))                                    AS `suggest_product_number`
  from (((((`whweo`.`view_mm_market_demand_plan_push_one` `a` left join `whweo`.`sm_store` `b`
      on (((`a`.`product_code` = `b`.`material_code`) and
           (`a`.`special_requirement` = `b`.`special_requirement`)))) left join `whweo`.`sm_store_safe` `c`
      on (((`a`.`product_code` = `c`.`material_code`) and
           (`a`.`special_requirement` = `c`.`special_requirement`)))) left join `whweo`.`pc_product_demand_plan` `d`
      on (((`a`.`product_code` = `d`.`material_code`) and (`a`.`special_requirement` = `d`.`special_requirement`) and
           (`d`.`predict_demand_time` >= now()) and
           (`d`.`predict_demand_time` < `a`.`suggest_delivery_date`)))) left join `whweo`.`sm_store` `e`
      on (((`d`.`material_code` = `e`.`material_code`) and (`d`.`special_requirement` = `e`.`special_requirement`) and
           (`d`.`sale_demand_code` = `e`.`demand_plan_code`)))) left join `whweo`.`mm_sale_order_item` `f` on ((
    (`a`.`product_code` = `f`.`product_code`) and (`a`.`special_requirement` = `f`.`special_requirement`) and
    (`f`.`suggest_delivery_date` >= date_format(now(), '%Y-%m-01')) and
    (`f`.`suggest_delivery_date` < `a`.`suggest_delivery_date`) and (`f`.`approval_state` = 1) and
    (`f`.`is_shipping` = 0))))
  group by `a`.`product_code`, `a`.`special_requirement`, `a`.`push_down_number`;

