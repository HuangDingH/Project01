create view view_sm_sale_order_store as
  select
    `b`.`order_code`            AS `order_code`,
    `b`.`product_code`          AS `product_code`,
    `b`.`product_name`          AS `product_name`,
    `b`.`base_unit_name`        AS `base_unit_name`,
    `b`.`total_amount`          AS `actual_delivery_quantity`,
    `b`.`price`                 AS `price`,
    `b`.`include_tax_price`     AS `sale_price`,
    `b`.`total_money`           AS `account`,
    `b`.`tax_rate`              AS `tax_rate`,
    `b`.`total_tax`             AS `sale_account`,
    `b`.`create_date`           AS `create_date`,
    `b`.`suggest_delivery_date` AS `suggest_delivery_date`,
    `b`.`order_number`          AS `order_number`,
    `a`.`company_code`          AS `company_code`,
    `a`.`company_name`          AS `company_name`,
    `a`.`shipping_way`          AS `shipping_way`,
    `a`.`approval_state`        AS `approval_state`,
    `a`.`salesmen_name`         AS `salesmen_name`,
    `c`.`warehouse_entry_code`  AS `warehouse_entry_code`,
    `c`.`material_code`         AS `material_code`,
    `c`.`batch_code`            AS `batch_code`,
    `c`.`inventory_quantity`    AS `inventory_quantity`,
    `c`.`store_house_id`        AS `store_house_id`,
    `c`.`store_house_name`      AS `store_house_name`,
    `c`.`store_position_id`     AS `store_position_id`,
    `c`.`store_position_name`   AS `store_position_name`,
    `c`.`material_name`         AS `material_name`,
    `c`.`sheets_quantity`       AS `sheets_quantity`,
    `c`.`quantity_of_units`     AS `quantity_of_units`
  from ((`whweo`.`mm_sale_order` `a`
    join `whweo`.`mm_sale_order_item` `b` on ((`a`.`order_code` = `b`.`order_code`))) left join `whweo`.`sm_store` `c`
      on ((`b`.`product_code` = `c`.`material_code`)));

