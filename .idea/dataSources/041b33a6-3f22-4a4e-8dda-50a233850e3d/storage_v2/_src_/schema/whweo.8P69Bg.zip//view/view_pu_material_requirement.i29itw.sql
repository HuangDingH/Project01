create view view_pu_material_requirement as
  select
    `b`.`id`                         AS `id`,
    `b`.`material_requirement_code`  AS `material_requirement_code`,
    `b`.`sale_demand_batch_code`     AS `sale_demand_batch_code`,
    `b`.`material_code`              AS `material_code`,
    `b`.`serial_number`              AS `serial_number`,
    `c`.`material_name`              AS `material_name`,
    `c`.`specification`              AS `specification`,
    `c`.`material_type_name`         AS `material_type_name`,
    `b`.`demand_quantity`            AS `demand_quantity`,
    `d`.`instant_amount`             AS `instant_amount`,
    `b`.`purchase_plan_aid_quantity` AS `purchase_plan_aid_quantity`,
    `b`.`purchase_plan_quantity`     AS `purchase_plan_quantity`,
    `c`.`main_unit`                  AS `unit`,
    `b`.`unit_price`                 AS `unit_price`,
    `b`.`document_maker_name`        AS `document_maker_name`,
    `b`.`document_make_date`         AS `document_make_date`,
    `b`.`push_date`                  AS `push_date`,
    `b`.`push_state`                 AS `push_state`,
    `b`.`note`                       AS `note`
  from ((`whweo`.`pu_material_requirement` `b`
    join `whweo`.`bdp_material` `c` on ((`b`.`material_code` = `c`.`material_code`))) left join
    `whweo`.`view_store_safe` `d` on ((`b`.`material_code` = `d`.`material_code`)));

