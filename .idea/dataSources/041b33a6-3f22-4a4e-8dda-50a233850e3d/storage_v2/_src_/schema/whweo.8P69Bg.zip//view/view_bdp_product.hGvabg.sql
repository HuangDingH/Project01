create view view_bdp_product as
  select
    `a`.`id`                          AS `id`,
    `a`.`name`                        AS `name`,
    `a`.`code`                        AS `code`,
    `a`.`product_type_id`             AS `product_type_id`,
    `a`.`product_type_name`           AS `product_type_name`,
    `a`.`weight`                      AS `weight`,
    `a`.`warranty`                    AS `warranty`,
    `a`.`storage_way`                 AS `storage_way`,
    `a`.`note`                        AS `note`,
    `a`.`is_use`                      AS `is_use`,
    `a`.`modifier_code`               AS `modifier_code`,
    `a`.`modifier_name`               AS `modifier_name`,
    `a`.`gmt_create`                  AS `gmt_create`,
    `a`.`gmt_modified`                AS `gmt_modified`,
    `b`.`specification`               AS `specification`,
    `b`.`serial_code`                 AS `serial_code`,
    `b`.`default_store_house_name`    AS `default_store_house_name`,
    `b`.`default_store_position_name` AS `default_store_position_name`,
    `b`.`main_unit`                   AS `main_unit`,
    `b`.`material_attribute`          AS `material_attribute`,
    `b`.`material_kind`               AS `material_kind`
  from (`whweo`.`bdp_product` `a`
    join `whweo`.`bdp_material` `b` on ((`a`.`code` = `b`.`material_code`)));

