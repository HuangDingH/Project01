create view view_pm_deduction_work_hours_sum as
  select
    `c`.`code`            AS `code`,
    `c`.`name`            AS `name`,
    sum(`c`.`work_hours`) AS `work_hours`,
    `c`.`checkout_int`    AS `checkout_int`
  from `whweo`.`pm_user_deduction_efficiency_record` `c`
  where (`c`.`checkout_int` = 1)
  group by `c`.`code`;

