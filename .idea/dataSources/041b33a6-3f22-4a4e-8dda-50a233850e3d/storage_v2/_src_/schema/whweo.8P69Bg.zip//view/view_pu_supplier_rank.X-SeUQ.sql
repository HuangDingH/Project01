create view view_pu_supplier_rank as
  select
    `a`.`supplier_code`            AS `supplier_code`,
    `a`.`material_code`            AS `material_code`,
    `a`.`ranking_rule_id`          AS `ranking_rule_id`,
    `b`.`supplier_evaluation_rule` AS `supplier_evaluation_rule`,
    `b`.`parent_rule`              AS `parent_rule`,
    `b`.`show_order`               AS `show_order`,
    `a`.`score`                    AS `score`
  from (`whweo`.`pu_supplier_rank` `a`
    join `whweo`.`pu_supplier_ranking_rule` `b` on ((`a`.`ranking_rule_id` = `b`.`id`)));

