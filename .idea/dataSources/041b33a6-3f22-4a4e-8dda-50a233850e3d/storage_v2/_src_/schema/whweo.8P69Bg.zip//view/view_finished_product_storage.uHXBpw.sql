create view view_finished_product_storage as
  select
    `a`.`warehouse_entry_code`         AS `warehouse_entry_code`,
    `b`.`batch_code`                   AS `batch_code`,
    `b`.`material_code`                AS `material_code`,
    `b`.`material_name`                AS `material_name`,
    `b`.`specification_model`          AS `specification_model`,
    `b`.`textures`                     AS `textures`,
    `b`.`sterilization_code`           AS `sterilization_code`,
    `b`.`units`                        AS `units`,
    `b`.`receive_quantity`             AS `receive_quantity`,
    `b`.`sheets_quantity`              AS `sheets_quantity`,
    `b`.`quantity_of_units`            AS `quantity_of_units`,
    `b`.`national_standard`            AS `national_standard`,
    `a`.`store_house_name`             AS `store_house_name`,
    `b`.`store_position_name`          AS `store_position_name`,
    `a`.`receive_name`                 AS `receive_name`,
    `a`.`create_name`                  AS `create_name`,
    `b`.`account_state`                AS `account_state`,
    `b`.`audit_time`                   AS `audit_time`,
    `b`.`audit_state`                  AS `audit_state`,
    `a`.`create_time`                  AS `create_time`,
    `b`.`checked_state`                AS `checked_state`,
    `a`.`abolish_state`                AS `abolish_state`,
    `b`.`supplier_name`                AS `supplier_name`,
    `b`.`identification_code`          AS `identification_code`,
    `b`.`quality_assurance_time_start` AS `quality_assurance_time_start`,
    `b`.`quality_assurance_time`       AS `quality_assurance_time`,
    `b`.`note`                         AS `note`,
    `a`.`head_note`                    AS `head_note`,
    `a`.`print_number`                 AS `print_number`
  from (`whweo`.`sm_storage_in` `a`
    join `whweo`.`sm_storage_detail_in` `b`
      on (((`a`.`warehouse_entry_code` = `b`.`warehouse_entry_code`) and (`a`.`warehouse_in_type` = '2'))));

