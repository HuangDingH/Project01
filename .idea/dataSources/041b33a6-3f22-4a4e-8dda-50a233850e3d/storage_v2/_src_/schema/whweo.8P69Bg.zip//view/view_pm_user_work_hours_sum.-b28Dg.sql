create view view_pm_user_work_hours_sum as select
                                             `a`.`code`                  AS `code`,
                                             `a`.`name`                  AS `name`,
                                             `a`.`machine_working_hours` AS `machine_working_hours`,
                                             `a`.`process_working_hours` AS `process_working_hours`,
                                             `b`.`efficiency`            AS `efficiency`,
                                             `c`.`work_hours`            AS `work_hours`
                                           from ((`whweo`.`view_pm_process_work_hours_sum` `a` left join
                                             `whweo`.`view_pm_assistant_work_hours_sum` `b`
                                               on ((`a`.`code` = `b`.`code`))) left join
                                             `whweo`.`view_pm_deduction_work_hours_sum` `c`
                                               on ((`a`.`code` = `c`.`code`)))
                                           union select
                                                   `b`.`code`                  AS `code`,
                                                   `b`.`name`                  AS `name`,
                                                   `a`.`machine_working_hours` AS `machine_working_hours`,
                                                   `a`.`process_working_hours` AS `process_working_hours`,
                                                   `b`.`efficiency`            AS `efficiency`,
                                                   `c`.`work_hours`            AS `work_hours`
                                                 from ((`whweo`.`view_pm_assistant_work_hours_sum` `b` left join
                                                   `whweo`.`view_pm_process_work_hours_sum` `a`
                                                     on ((`b`.`code` = `a`.`code`))) left join
                                                   `whweo`.`view_pm_deduction_work_hours_sum` `c`
                                                     on ((`b`.`code` = `c`.`code`)))
                                           union select
                                                   `c`.`code`                  AS `code`,
                                                   `c`.`name`                  AS `name`,
                                                   `a`.`machine_working_hours` AS `machine_working_hours`,
                                                   `a`.`process_working_hours` AS `process_working_hours`,
                                                   `b`.`efficiency`            AS `efficiency`,
                                                   `c`.`work_hours`            AS `work_hours`
                                                 from ((`whweo`.`view_pm_deduction_work_hours_sum` `c` left join
                                                   `whweo`.`view_pm_process_work_hours_sum` `a`
                                                     on ((`c`.`code` = `a`.`code`))) left join
                                                   `whweo`.`view_pm_assistant_work_hours_sum` `b`
                                                     on ((`c`.`code` = `b`.`code`)));

