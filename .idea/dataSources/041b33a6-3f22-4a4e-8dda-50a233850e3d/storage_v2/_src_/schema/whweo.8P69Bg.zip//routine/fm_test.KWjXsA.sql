create procedure fm_test(IN gi int, OUT gindex int)
  label_pro:BEGIN
	#Routine body goes here...
START TRANSACTION;
IF (gi=1) THEN
INSERT INTO sm_storage_detail_in SET warehouse_entry_code=2211;
ROLLBACK;
set gindex=4;
LEAVE label_pro;
END IF;

COMMIT;
set gindex=0;
END;

