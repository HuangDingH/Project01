create view view_pu_purchase_material_check as
  select
    `b`.`quality_check_code`        AS `quality_check_code`,
    `b`.`purchase_order_code`       AS `purchase_order_code`,
    `b`.`batch_code`                AS `batch_code`,
    `b`.`material_code`             AS `material_code`,
    `b`.`material_name`             AS `material_name`,
    `b`.`specification`             AS `specification`,
    `a`.`purchase_quantity`         AS `purchase_quantity`,
    `b`.`arrival_quantity`          AS `arrival_quantity`,
    `b`.`store_quantity`            AS `store_quantity`,
    `b`.`unit`                      AS `unit`,
    `a`.`unit_price`                AS `unit_price`,
    `a`.`supplier_code`             AS `supplier_code`,
    `a`.`supplier_name`             AS `supplier_name`,
    `b`.`apply_check_date`          AS `apply_check_date`,
    `b`.`check_state`               AS `check_state`,
    `b`.`store_state`               AS `store_state`,
    `b`.`note`                      AS `note`,
    `a`.`material_requirement_code` AS `material_requirement_code`,
    `a`.`purchasing_way`            AS `purchasing_way`,
    `b`.`id`                        AS `id`,
    `a`.`tax`                       AS `tax`
  from (`whweo`.`qu_raw_material_check_application` `b` left join `whweo`.`pu_purchase_order` `a`
      on (((`a`.`purchase_order_code` = `b`.`purchase_order_code`) and (`a`.`material_code` = `b`.`material_code`))));

