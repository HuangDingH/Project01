create view view_pu_purchase_contract_material as
  select
    `a`.`purchase_contract_code` AS `purchase_contract_code`,
    `b`.`material_code`          AS `material_code`,
    `c`.`material_name`          AS `material_name`,
    `c`.`specification`          AS `specification`,
    `c`.`material_type_name`     AS `material_type_name`,
    `b`.`purchase_plan_quantity` AS `purchase_plan_quantity`,
    `b`.`purchase_quantity`      AS `purchase_quantity`,
    `c`.`main_unit`              AS `unit`,
    `b`.`unit_price`             AS `unit_price`,
    `b`.`tax`                    AS `tax`,
    `b`.`process_instance_id`    AS `process_instance_id`
  from ((`whweo`.`pu_purchase_contract` `a`
    join `whweo`.`pu_purchase_contract_material` `b`
      on ((`a`.`purchase_contract_code` = `b`.`purchase_contract_code`))) join `whweo`.`bdp_material` `c`
      on ((`b`.`material_code` = `c`.`material_code`)));

