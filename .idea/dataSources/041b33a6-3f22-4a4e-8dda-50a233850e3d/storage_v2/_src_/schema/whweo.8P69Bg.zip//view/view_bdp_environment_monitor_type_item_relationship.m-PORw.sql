create view view_bdp_environment_monitor_type_item_relationship as
  select
    `whweo`.`bdp_environment_monitor_type_item_relationship`.`type_id`       AS `type_id`,
    `whweo`.`bdp_environment_monitor_type_item_relationship`.`item_id`       AS `item_id`,
    `whweo`.`bdp_environment_monitor_type_item_relationship`.`modifier_name` AS `modifier_name`,
    `whweo`.`bdp_environment_monitor_type_item_relationship`.`modifier_code` AS `modifier_code`,
    `whweo`.`bdp_environment_monitor_type_item_relationship`.`id`            AS `id`,
    `whweo`.`bdp_environment_monitor_type_item_relationship`.`gmt_create`    AS `gmt_create`,
    `whweo`.`bdp_environment_monitor_type_item_relationship`.`gmt_modified`  AS `gmt_modified`,
    `whweo`.`bdp_environment_monitor_item`.`code`                            AS `code`,
    `whweo`.`bdp_environment_monitor_item`.`name`                            AS `name`
  from (`whweo`.`bdp_environment_monitor_type_item_relationship`
    left join `whweo`.`bdp_environment_monitor_item`
      on ((`whweo`.`bdp_environment_monitor_type_item_relationship`.`item_id` =
           `whweo`.`bdp_environment_monitor_item`.`id`)));

