create view view_pc_process_order_target_amount as
  select
    `a`.`id`                     AS `id`,
    `a`.`production_order_id`    AS `production_order_id`,
    `a`.`production_order_code`  AS `production_order_code`,
    `a`.`production_batch_code`  AS `production_batch_code`,
    `a`.`production_order_type`  AS `production_order_type`,
    `a`.`material_code`          AS `material_code`,
    `a`.`material_name`          AS `material_name`,
    `m`.`specification`          AS `specification`,
    `a`.`bom_id`                 AS `bom_id`,
    `a`.`process_id`             AS `process_id`,
    `a`.`process_code`           AS `process_code`,
    `a`.`process_name`           AS `process_name`,
    `a`.`process_type_id`        AS `process_type_id`,
    sum(`d`.`production_amount`) AS `target_amount`,
    `a`.`good_amount`            AS `good_amount`,
    `a`.`bad_amount`             AS `bad_amount`,
    `a`.`bad_process_amount`     AS `bad_process_amount`,
    `a`.`bad_material_amount`    AS `bad_material_amount`,
    `a`.`state_type`             AS `state_type`,
    `a`.`state_name`             AS `state_name`,
    `a`.`order_state_start_time` AS `order_state_start_time`,
    `a`.`plan_start_time`        AS `plan_start_time`,
    `a`.`plan_end_time`          AS `plan_end_time`,
    `a`.`actual_start_time`      AS `actual_start_time`,
    `a`.`actual_end_time`        AS `actual_end_time`
  from ((`whweo`.`pc_process_order` `a` left join `whweo`.`pc_production_daily_plan` `d`
      on ((`a`.`production_order_id` = `d`.`production_order_id`))) left join `whweo`.`bdp_material` `m`
      on ((`a`.`material_code` = `m`.`material_code`)))
  group by `a`.`id`;

