create view view_pc_product_real_time_produced as
  select
    `a`.`id`                          AS `id`,
    `a`.`material_code`               AS `material_code`,
    ifnull(sum(`b`.`good_amount`), 0) AS `produced_amount`
  from ((`whweo`.`pc_product_beginning_info` `a` left join `whweo`.`view_pc_product_real_time_maxtime` `c`
      on ((`c`.`material_code` = `a`.`material_code`))) left join `whweo`.`ex_turnover_batch_code` `b`
      on (((`a`.`material_code` = `b`.`material_code`) and (`b`.`state_type` = 4) and
           (`b`.`end_time` > `c`.`max_beginning_time`))))
  group by `a`.`material_code`;

