create view view_pc_product_production_plan as
  select
    `a`.`id`                                                                 AS `id`,
    `a`.`production_plan_code`                                               AS `production_plan_code`,
    `a`.`material_code`                                                      AS `material_code`,
    `a`.`material_name`                                                      AS `material_name`,
    `a`.`specification`                                                      AS `specification`,
    `a`.`serial_code`                                                        AS `serial_code`,
    `a`.`production_amount`                                                  AS `production_amount`,
    `a`.`unit`                                                               AS `unit`,
    `a`.`priority`                                                           AS `priority`,
    `a`.`bom_id`                                                             AS `bom_id`,
    `a`.`bom_version`                                                        AS `bom_version`,
    `a`.`production_batch_code`                                              AS `production_batch_code`,
    `a`.`sterilizer_batch_code`                                              AS `sterilizer_batch_code`,
    `a`.`predict_sterilizer_time`                                            AS `predict_sterilizer_time`,
    `a`.`predict_demand_time`                                                AS `predict_demand_time`,
    `a`.`status_int`                                                         AS `status_int`,
    `a`.`status_name`                                                        AS `status_name`,
    `a`.`note`                                                               AS `note`,
    `a`.`gmt_create`                                                         AS `gmt_create`,
    `a`.`gmt_modified`                                                       AS `gmt_modified`,
    `a`.`modifier_code`                                                      AS `modifier_code`,
    `a`.`modifier_name`                                                      AS `modifier_name`,
    `b`.`number_of_bins`                                                     AS `number_of_bins`,
    cast((`a`.`production_amount` / `b`.`number_of_bins`) as decimal(20, 8)) AS `production_package`
  from (`whweo`.`pc_product_production_plan` `a` left join `whweo`.`bdp_material` `b`
      on ((`a`.`material_code` = `b`.`material_code`)));

