create view view_bom_process_efficiency as
  select
    `ef`.`id`                 AS `id`,
    `ef`.`bom_id`             AS `bom_id`,
    `ef`.`process_id`         AS `process_id`,
    `ef`.`efficiency`         AS `efficiency`,
    `ef`.`efficiency_unit`    AS `efficiency_unit`,
    `ef`.`version`            AS `version`,
    `ef`.`is_default_version` AS `is_default_version`,
    `ef`.`work_center_id`     AS `work_center_id`,
    `wc`.`work_center_code`   AS `work_center_code`,
    `wc`.`work_center_name`   AS `work_center_name`,
    `ef`.`mould_id`           AS `mould_id`,
    `mj`.`mould_code`         AS `mould_code`,
    `mj`.`mould_name`         AS `mould_name`,
    `ef`.`modifier_code`      AS `modifier_code`,
    `ef`.`modifier_name`      AS `modifier_name`,
    `ef`.`gmt_create`         AS `gmt_create`,
    `ef`.`gmt_modified`       AS `gmt_modified`
  from ((`whweo`.`bdp_bom_process_efficiency` `ef` left join `whweo`.`bdp_work_center` `wc`
      on ((`ef`.`work_center_id` = `wc`.`id`))) left join `whweo`.`mj_mould_ledger` `mj`
      on ((`ef`.`mould_id` = `mj`.`id`)));

