create view view_pu_supplier_material as
  select
    `b`.`id`                  AS `id`,
    `b`.`supplier_code`       AS `supplier_code`,
    `a`.`supplier_name`       AS `supplier_name`,
    `a`.`recipient`           AS `recipient`,
    `a`.`telephone`           AS `telephone`,
    `a`.`fax`                 AS `fax`,
    `b`.`material_code`       AS `material_code`,
    `c`.`material_name`       AS `material_name`,
    `c`.`specification`       AS `specification`,
    `b`.`process_instance_id` AS `process_instance_id`,
    `b`.`status`              AS `status`,
    `b`.`version`             AS `version`
  from ((`whweo`.`pu_supplier` `a`
    join `whweo`.`pu_supplier_material` `b` on ((`a`.`supplier_code` = `b`.`supplier_code`))) join
    `whweo`.`bdp_material` `c` on ((`b`.`material_code` = `c`.`material_code`)));

