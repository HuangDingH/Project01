create view view_pc_actual_production_amount_sum as
  select
    `a`.`material_code`                                                 AS `material_code`,
    `a`.`material_name`                                                 AS `material_name`,
    ifnull(sum(`a`.`good_amount`), 0)                                   AS `actual_production_amount`,
    date_format(`a`.`end_time`, '%Y-%m-%d 00:00:00')                    AS `production_date`,
    date_format((`a`.`end_time` + interval 1 day), '%Y-%m-%d 00:00:00') AS `end_time`
  from `whweo`.`ex_turnover_batch_code` `a`
  where (`a`.`state_type` = 4)
  group by date_format(`a`.`end_time`, '%Y-%m-%d 00:00:00');

