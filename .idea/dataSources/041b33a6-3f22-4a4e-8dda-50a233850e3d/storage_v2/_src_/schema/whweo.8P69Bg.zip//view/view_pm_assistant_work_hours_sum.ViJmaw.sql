create view view_pm_assistant_work_hours_sum as
  select
    `b`.`code`            AS `code`,
    `b`.`name`            AS `name`,
    sum(`b`.`efficiency`) AS `efficiency`,
    `b`.`checkout_int`    AS `checkout_int`
  from `whweo`.`pm_user_assistant_efficiency_record` `b`
  where (`b`.`checkout_int` = 1)
  group by `b`.`code`;

