create view view_materials_in_bom as
  select
    `bm`.`bom_id`        AS `bom_id`,
    `bm`.`material_code` AS `material_code`,
    `m`.`material_name`  AS `material_name`,
    `m`.`main_unit`      AS `main_unit`
  from (`whweo`.`bdp_bom_material` `bm` left join `whweo`.`bdp_material` `m`
      on ((`m`.`material_code` = `bm`.`material_code`)));

