create view view_pc_real_time_stock as
  select
    `whweo`.`sm_store`.`material_code`                      AS `material_code`,
    ifnull(sum(`whweo`.`sm_store`.`inventory_quantity`), 0) AS `real_time_stock_amount`
  from `whweo`.`sm_store`
  where (`whweo`.`sm_store`.`material_state_type` = 4)
  group by `whweo`.`sm_store`.`material_code`;

