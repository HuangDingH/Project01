create view view_bdp_work_center_and_mould as
  select
    `a`.`id`                  AS `id`,
    `a`.`work_center_id`      AS `work_center_id`,
    `a`.`mould_ledger_id`     AS `mould_ledger_id`,
    `a`.`gmt_create`          AS `gmt_create`,
    `a`.`gmt_modified`        AS `gmt_modified`,
    `a`.`modifier_code`       AS `modifier_code`,
    `a`.`modifier_name`       AS `modifier_name`,
    `b`.`mould_name`          AS `mould_name`,
    `b`.`mould_code`          AS `mould_code`,
    `b`.`mould_type`          AS `mould_type`,
    `b`.`mould_identify_code` AS `mould_identify_code`
  from (`whweo`.`bdp_work_center_and_mould` `a` left join `whweo`.`mj_mould_ledger` `b`
      on ((`a`.`mould_ledger_id` = `b`.`id`)));

