create procedure fm_purchase_verifying_pro(IN  gyear  varchar(4), IN gmonth varchar(2), IN fillman varchar(20),
                                           OUT gindex int)
  label_pro:BEGIN
	#Routine body goes here...

#定义全局变量
DECLARE sysdate varchar(50); #系统时间
DECLARE nyear varchar(4); #上期的年
DECLARE nmonth varchar(2); #上期的月
DECLARE nnum int;
DECLARE num int;
DECLARE ndate varchar(50); #系统上期核算时间
DECLARE TempInt int; #临时变量

#判断并删除临时表
drop table if exists TempReconciliation;
drop table if exists TempCustomerNotMarid;

#开始事物
START TRANSACTION;

#获取当前系统时间和上期年月
SET sysdate=CONVERT(NOW(),CHAR); 
IF(gmonth=01) THEN
SET nmonth='12';
SET nyear = CONVERT((CONVERT(gyear,SIGNED))-1,CHAR);
ELSE
SET nmonth = CONVERT((CONVERT(gmonth,SIGNED))-1,CHAR);
SET nnum=LENGTH(nmonth);
IF(nnum=1) THEN
SET nmonth=CONCAT('0',nmonth);
END IF;
SET nyear=gyear;
END IF;

#向采购对账明细表中插入当月新增采购发票和采购付款数据
INSERT INTO fm_purchase_reconciliation_detail (delivery_time,customer_name,product_name,product_code,specification,configuration,quantity,price,delivery_amount,paid_amount,arrears_amount,sales_order,arrival_time,note,verification_year,verification_month,verification_time,verification_name,invoice_code) SELECT payment_time,supplier_name,material_name,material_code,'',unit,quantity,tax_unit_price,total_tax_money,0,total_tax_money,'','',note,gyear,gmonth,sysdate,fillman,invoice_code FROM fm_purchase_invoice WHERE verification_state=0 and state=2 AND accounting_year=gyear AND accounting_month=gmonth;

UPDATE fm_purchase_invoice SET verification_state=1, verification_time=sysdate WHERE state=2 AND accounting_year=gyear AND accounting_month=gmonth;

INSERT INTO fm_purchase_reconciliation_detail (delivery_time,customer_name,product_name,product_code,specification,configuration,batch,quantity,price,delivery_amount,paid_amount,arrears_amount,sales_order,arrival_time,note,verification_year,verification_month,verification_time,verification_name) SELECT payment_date,client_name,purpose,'','','','',0,0,0,original_amount,0,'','','',gyear,gmonth,sysdate,fillman FROM fm_payment WHERE verification_state=0 and audit_state=2 AND verification_year=gyear AND verification_month=gmonth;

UPDATE fm_payment SET verification_state=1, verification_time=sysdate WHERE audit_state=2 AND verification_year=gyear AND verification_month=gmonth;

#向采购对账汇总表中插入当月数据，同时结转上月数据
#清空收发存汇总表本月将要核算的数据
DELETE FROM fm_purchase_reconciliation WHERE verification_year=gyear AND verification_month=gmonth;
#ALTER table fm_purchase_reconciliation AUTO_INCREMENT=1;

#将上月采购对账汇总数据结转至本月
INSERT INTO fm_purchase_reconciliation (customer_name,beginning_balance,account_paid,account_payable,end_balance,verification_year,verification_month,verification_time,verification_name) SELECT customer_name,end_balance,0,0,0,gyear,gmonth,sysdate,fillman FROM fm_purchase_reconciliation WHERE verification_year=nyear AND verification_month=nmonth;

#获取本月采购对账汇总数据
CREATE TEMPORARY TABLE TempReconciliation(SELECT customer_name, SUM(paid_amount) as account_paid, SUM(arrears_amount) as account_payable FROM fm_purchase_reconciliation_detail where verification_year=gyear AND verification_month=gmonth GROUP BY customer_name,verification_year,verification_month);
#SELECT * FROM TempReconciliation;

#找出本月采购对账数据中是否有对账汇总表里没有的客户，如果没有，标记为'1',并存入临时表中（防错处理）
CREATE TEMPORARY TABLE TempCustomerNotMarid SELECT *,case when c.id is null then '1' else '0' end as IsExist from (SELECT a.*,b.id FROM TempReconciliation as a LEFT OUTER JOIN (SELECT * FROM fm_purchase_reconciliation WHERE verification_year=gyear AND verification_month=gmonth) as b ON a.customer_name=b.customer_name)c;
#SELECT * FROM TempCustomerNotMarid;

#将本月新增的供应商采购对账数据插入采购对账汇总表
INSERT INTO fm_purchase_reconciliation (customer_name,beginning_balance,account_payable,account_paid,end_balance,verification_year,verification_month,verification_time,verification_name) SELECT customer_name,0,IFNULL(account_payable,0),IFNULL(account_paid,0),0,gyear,gmonth,sysdate,fillman FROM TempCustomerNotMarid WHERE IsExist=1;

#更新采购对账汇总表中的本期已付金额，本期应付金额
UPDATE fm_purchase_reconciliation as a LEFT OUTER JOIN TempReconciliation as b ON a.customer_name=b.customer_name SET a.account_paid=IFNULL(b.account_paid,0), a.account_payable=IFNULL(b.account_payable,0) WHERE a.verification_year=gyear AND a.verification_month=gmonth;

#更新采购对账汇总表中的期末数据
UPDATE fm_purchase_reconciliation SET end_balance=beginning_balance+account_payable-account_paid WHERE verification_year=gyear AND verification_month=gmonth;

#删除为0的数据
DELETE FROM fm_purchase_reconciliation WHERE verification_year=gyear AND verification_month=gmonth AND beginning_balance=0 AND account_paid=0 AND account_payable=0 AND end_balance=0;

#检查是否在核销过程中插入了新的采购发票，付款单，如果有则核算失败
#存在未成功核销的采购发票
set TempInt=(select count(*) FROM fm_purchase_invoice where accounting_year=gyear AND accounting_month=gmonth and verification_state<>1 and state=2);
if(TempInt>0) THEN
ROLLBACK;
set gindex=1;
drop table if exists TempReconciliation;
drop table if exists TempCustomerNotMarid;
LEAVE label_pro;
END IF;

#存在未成功核销的付款单
set TempInt=(select count(*) FROM fm_payment where verification_year=gyear AND verification_month=gmonth and verification_state<>1 and audit_state=2);
if(TempInt>0) THEN
ROLLBACK;
set gindex=2;
drop table if exists TempReconciliation;
drop table if exists TempCustomerNotMarid;
LEAVE label_pro;
END IF;

COMMIT;
set gindex=0;
END;

