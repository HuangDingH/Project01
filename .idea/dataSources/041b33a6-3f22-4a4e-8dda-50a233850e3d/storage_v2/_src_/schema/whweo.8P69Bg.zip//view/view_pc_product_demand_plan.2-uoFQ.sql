create view view_pc_product_demand_plan as
  select
    `a`.`id`                                                                 AS `id`,
    `a`.`sale_demand_batch_code`                                             AS `sale_demand_batch_code`,
    `a`.`sale_demand_code`                                                   AS `sale_demand_code`,
    `a`.`material_code`                                                      AS `material_code`,
    `a`.`material_name`                                                      AS `material_name`,
    `a`.`specification`                                                      AS `specification`,
    `a`.`serial_code`                                                        AS `serial_code`,
    `a`.`production_amount`                                                  AS `production_amount`,
    `a`.`unit`                                                               AS `unit`,
    `a`.`priority`                                                           AS `priority`,
    `a`.`special_requirement`                                                AS `special_requirement`,
    `a`.`bom_id`                                                             AS `bom_id`,
    `a`.`bom_version`                                                        AS `bom_version`,
    `a`.`predict_demand_time`                                                AS `predict_demand_time`,
    `a`.`note`                                                               AS `note`,
    `a`.`gmt_create`                                                         AS `gmt_create`,
    `a`.`gmt_modified`                                                       AS `gmt_modified`,
    `a`.`modifier_code`                                                      AS `modifier_code`,
    `a`.`modifier_name`                                                      AS `modifier_name`,
    `a`.`status_int`                                                         AS `status_int`,
    `a`.`status_name`                                                        AS `status_name`,
    cast((`a`.`production_amount` / `b`.`number_of_bins`) as decimal(20, 8)) AS `production_package`,
    (`a`.`production_amount` - ifnull(sum(`c`.`amount`), 0))                 AS `remain_amount`
  from ((`whweo`.`pc_product_demand_plan` `a` left join `whweo`.`bdp_material` `b`
      on ((`a`.`material_code` = `b`.`material_code`))) left join `whweo`.`pc_product_demand_and_production` `c`
      on ((`a`.`id` = `c`.`demand_id`)))
  group by `a`.`id`;

