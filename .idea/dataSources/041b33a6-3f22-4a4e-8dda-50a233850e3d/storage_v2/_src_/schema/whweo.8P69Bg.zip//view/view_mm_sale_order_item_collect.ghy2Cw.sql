create view view_mm_sale_order_item_collect as
  select
    `a`.`id`                                                                                                  AS `id`,
    `a`.`order_code`                                                                                          AS `order_code`,
    `a`.`company_name`                                                                                        AS `company_name`,
    `a`.`company_code`                                                                                        AS `company_code`,
    `a`.`product_code`                                                                                        AS `product_code`,
    `a`.`product_name`                                                                                        AS `product_name`,
    `a`.`specification_type`                                                                                  AS `specification_type`,
    `a`.`serial_number`                                                                                       AS `serial_number`,
    `a`.`total_amount`                                                                                        AS `total_amount`,
    `a`.`suggest_delivery_date`                                                                               AS `suggest_delivery_date`,
    (to_days(date_format(`a`.`suggest_delivery_date`, '%Y-%m-%d')) - to_days(date_format(now(),
                                                                                         '%Y-%m-%d')))        AS `time_reduce`,
    `a`.`special_requirement`                                                                                 AS `special_requirement`,
    `a`.`note`                                                                                                AS `note`,
    `a`.`is_push_down`                                                                                        AS `is_push_down`,
    `a`.`approval_state`                                                                                      AS `approval_state`,
    `a`.`order_number`                                                                                        AS `order_number`,
    `a`.`start_time`                                                                                          AS `start_time`,
    `a`.`end_time`                                                                                            AS `end_time`,
    `a`.`create_date`                                                                                         AS `create_date`
  from `whweo`.`mm_sale_order_item` `a`;

