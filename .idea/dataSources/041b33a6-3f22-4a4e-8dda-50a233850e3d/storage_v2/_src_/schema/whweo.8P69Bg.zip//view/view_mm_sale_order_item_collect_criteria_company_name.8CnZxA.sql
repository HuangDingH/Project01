create view view_mm_sale_order_item_collect_criteria_company_name as
  select
    `whweo`.`mm_sale_order_item`.`company_name` AS `company_name`,
    `whweo`.`mm_sale_order_item`.`company_code` AS `company_code`
  from `whweo`.`mm_sale_order_item`;

