create view em_sum_test as
  select
    `p`.`time_date`                        AS `time_date`,
    `p`.`time_date`                        AS `begin_date`,
    `p`.`time_date`                        AS `end_date`,
    `p`.`equipment_name`                   AS `equipment_name`,
    `p`.`equipment_code`                   AS `equipment_code`,
    `p`.`output_name`                      AS `output_name`,
    `p`.`mould_code`                       AS `mould_code`,
    `p`.`output_production_batch_code`     AS `output_production_batch_code`,
    `p`.`process_id`                       AS `process_id`,
    `p`.`correspond_process`               AS `correspond_process`,
    `p`.`productivity`                     AS `productivity`,
    `p`.`productivity_unit`                AS `productivity_unit`,
    round(avg(`p`.`real_productivity`), 0) AS `real_productivity`,
    `p`.`real_productivity_unit`           AS `real_productivity_unit`,
    round(sum(`p`.`work_time`), 2)         AS `work_time`,
    `p`.`time_unit`                        AS `time_unit`,
    sum(`p`.`qualified_amount`)            AS `qualified_amount`,
    sum(`p`.`unqualified_amount`)          AS `unqualified_amount`,
    sum(`p`.`output_amount`)               AS `output_amount`,
    `p`.`amount_unit`                      AS `amount_unit`
  from `whweo`.`em_equipment_use_detail` `p`
  group by `p`.`time_date`, `p`.`equipment_code`, `p`.`mould_code`, `p`.`output_production_batch_code`,
    `p`.`process_id`;

