create view view_pc_demand_daily_plan as
  select
    `whweo`.`pc_demand_daily_plan`.`material_code`                          AS `material_code`,
    `whweo`.`pc_demand_daily_plan`.`material_name`                          AS `material_name`,
    `whweo`.`pc_demand_daily_plan`.`material_attribute`                     AS `material_attribute`,
    `whweo`.`pc_demand_daily_plan`.`specification`                          AS `specification`,
    `whweo`.`pc_demand_daily_plan`.`group_name`                             AS `group_name`,
    sum(`whweo`.`pc_demand_daily_plan`.`demand_amount`)                     AS `demand_amount`,
    `whweo`.`pc_demand_daily_plan`.`unit`                                   AS `unit`,
    `whweo`.`pc_demand_daily_plan`.`predict_demand_time`                    AS `predict_demand_time`,
    (`whweo`.`pc_demand_daily_plan`.`predict_demand_time` + interval 1 day) AS `end_time`,
    `whweo`.`pc_demand_daily_plan`.`plan_time`                              AS `plan_time`
  from `whweo`.`pc_demand_daily_plan`
  group by `whweo`.`pc_demand_daily_plan`.`material_code`, `whweo`.`pc_demand_daily_plan`.`predict_demand_time`;

