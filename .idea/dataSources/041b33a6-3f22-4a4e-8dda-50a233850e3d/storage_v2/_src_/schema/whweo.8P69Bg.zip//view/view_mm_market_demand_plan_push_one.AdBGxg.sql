create view view_mm_market_demand_plan_push_one as
  select
    `a`.`product_code`                                              AS `product_code`,
    `a`.`product_name`                                              AS `product_name`,
    `a`.`specification_type`                                        AS `specification_type`,
    `a`.`serial_number`                                             AS `serial_number`,
    `a`.`special_requirement`                                       AS `special_requirement`,
    `a`.`base_unit_name`                                            AS `base_unit_name`,
    ifnull(sum(`a`.`base_unit_amount`), 0)                          AS `total_num`,
    min(`a`.`suggest_delivery_date`)                                AS `suggest_delivery_date`,
    group_concat(concat_ws('需货量为:', `a`.`suggest_delivery_date`, `a`.`base_unit_amount`) order by
                 `a`.`suggest_delivery_date` ASC separator '     ') AS `detail_requirements`,
    `a`.`note`                                                      AS `note`,
    `a`.`push_down_number`                                          AS `push_down_number`
  from `whweo`.`mm_sale_order_item` `a`
  group by `a`.`push_down_number`, `a`.`product_code`, `a`.`special_requirement`;

