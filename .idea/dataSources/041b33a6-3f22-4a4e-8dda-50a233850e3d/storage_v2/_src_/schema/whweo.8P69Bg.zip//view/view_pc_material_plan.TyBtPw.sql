create view view_pc_material_plan as
  select
    `a`.`id`                                 AS `id`,
    `a`.`material_code`                      AS `material_code`,
    `a`.`material_name`                      AS `material_name`,
    `a`.`material_attribute`                 AS `material_attribute`,
    `a`.`specification`                      AS `specification`,
    `a`.`group_name`                         AS `group_name`,
    `b`.`bom_id`                             AS `bom_id`,
    `b`.`process_id`                         AS `process_id`,
    `b`.`material_state_type`                AS `material_state_type`,
    `b`.`material_state_name`                AS `material_state_name`,
    ifnull(sum(`b`.`inventory_quantity`), 0) AS `amount`,
    `d`.`process_name`                       AS `process_name`,
    `e`.`safety_amount`                      AS `safety_amount`,
    now()                                    AS `nowTime`
  from ((((`whweo`.`bdp_material` `a` left join `whweo`.`sm_store` `b`
      on ((`a`.`material_code` = `b`.`material_code`))) left join `whweo`.`bdp_bom_process` `c`
      on (((`b`.`bom_id` = `c`.`bom_id`) and (`b`.`process_id` = `c`.`process_id`)))) left join
    `whweo`.`bdp_process` `d` on ((`c`.`process_id` = `d`.`id`))) left join `whweo`.`sm_store_safe` `e`
      on ((`a`.`material_code` = `e`.`material_code`)))
  where (not ((`a`.`material_code` like '41%')))
  group by `a`.`id`, `a`.`material_code`, `b`.`bom_id`, `b`.`process_id`, `b`.`material_state_type`;

