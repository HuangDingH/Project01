create view view_pc_part_real_time_outbound as
  select
    `a`.`id`                                       AS `id`,
    `a`.`material_code`                            AS `material_code`,
    ifnull(sum(`b`.`actual_delivery_quantity`), 0) AS `outbound_amount`
  from ((`whweo`.`pc_part_beginning_info` `a` left join `whweo`.`view_pc_part_real_time_maxtime` `c`
      on ((`a`.`material_code` = `c`.`material_code`))) left join `whweo`.`sm_storage_out_for_production` `b`
      on (((`a`.`material_code` = `b`.`material_code`) and (`b`.`audit_flag` = 2) and
           (`b`.`audit_date` > `c`.`max_beginning_time`))))
  group by `a`.`material_code`;

