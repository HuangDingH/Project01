create view view_em_equipment_use_period_summarise as
  select
    `view_em_equipment_use_daily_summarise`.`time_date`               AS `time_date`,
    `view_em_equipment_use_daily_summarise`.`equipment_code`          AS `equipment_code`,
    sum(`view_em_equipment_use_daily_summarise`.`qualified_amount`)   AS `SUM(qualified_amount)`,
    sum(`view_em_equipment_use_daily_summarise`.`unqualified_amount`) AS `SUM(unqualified_amount)`,
    sum(`view_em_equipment_use_daily_summarise`.`output_amount`)      AS `SUM(output_amount)`
  from `whweo`.`view_em_equipment_use_daily_summarise`
  where ((`view_em_equipment_use_daily_summarise`.`time_date` >= '2019-03-04') and
         (`view_em_equipment_use_daily_summarise`.`time_date` <= '2019-03-05'))
  group by `view_em_equipment_use_daily_summarise`.`time_date`,
    `view_em_equipment_use_daily_summarise`.`equipment_code`;

