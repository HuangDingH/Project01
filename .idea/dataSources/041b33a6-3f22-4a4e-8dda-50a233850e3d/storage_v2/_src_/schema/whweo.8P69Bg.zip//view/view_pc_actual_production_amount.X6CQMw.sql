create view view_pc_actual_production_amount as
  select
    `a`.`production_order_code`                                         AS `production_order_code`,
    `a`.`production_batch_code`                                         AS `production_batch_code`,
    `a`.`material_code`                                                 AS `material_code`,
    `a`.`material_name`                                                 AS `material_name`,
    ifnull(sum(`a`.`good_amount`), 0)                                   AS `actual_production_amount`,
    date_format(`a`.`end_time`, '%Y-%m-%d 00:00:00')                    AS `production_date`,
    date_format((`a`.`end_time` + interval 1 day), '%Y-%m-%d 00:00:00') AS `end_time`,
    `b`.`work_center_id`                                                AS `work_center_id`
  from (`whweo`.`ex_turnover_batch_code` `a` left join `whweo`.`pc_production_order` `b`
      on ((`a`.`production_order_code` = `b`.`production_order_code`)))
  where (`a`.`state_type` = 4)
  group by `a`.`production_order_code`, date_format(`a`.`end_time`, '%Y-%m-%d 00:00:00');

