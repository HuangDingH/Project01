create view view_pm_process_work_hours_sum as
  select
    `a`.`code`                       AS `code`,
    `a`.`name`                       AS `name`,
    sum(`a`.`machine_working_hours`) AS `machine_working_hours`,
    sum(`a`.`process_working_hours`) AS `process_working_hours`,
    `a`.`checkout_int`               AS `checkout_int`
  from `whweo`.`pm_user_performance` `a`
  where (`a`.`checkout_int` = 1)
  group by `a`.`code`;

