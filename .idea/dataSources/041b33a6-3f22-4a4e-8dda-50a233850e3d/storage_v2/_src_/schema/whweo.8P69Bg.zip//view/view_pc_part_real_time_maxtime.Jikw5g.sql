create view view_pc_part_real_time_maxtime as
  select
    `a`.`material_code`       AS `material_code`,
    max(`a`.`beginning_time`) AS `max_beginning_time`
  from `whweo`.`pc_part_beginning_info` `a`
  group by `a`.`material_code`;

