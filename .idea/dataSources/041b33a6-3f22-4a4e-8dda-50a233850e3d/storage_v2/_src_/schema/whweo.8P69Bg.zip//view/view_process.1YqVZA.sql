create view view_process as
  select
    `p`.`id`              AS `id`,
    `p`.`process_code`    AS `process_code`,
    `p`.`process_name`    AS `process_name`,
    `p`.`process_type_id` AS `process_type_id`,
    `di`.`name`           AS `process_type_name`,
    `p`.`gmt_create`      AS `gmt_create`,
    `p`.`gmt_modified`    AS `gmt_modified`,
    `p`.`modifier_code`   AS `modifier_code`,
    `p`.`modifier_name`   AS `modifier_name`
  from (`whweo`.`bdp_process` `p` left join `whweo`.`bdp_dict_info` `di` on ((`di`.`id` = `p`.`process_type_id`)));

