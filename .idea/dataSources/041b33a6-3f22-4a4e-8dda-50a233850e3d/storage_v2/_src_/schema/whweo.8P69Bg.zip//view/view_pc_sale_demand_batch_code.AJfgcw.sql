create view view_pc_sale_demand_batch_code as
  select
    `a`.`sale_demand_batch_code` AS `sale_demand_batch_code`,
    count(1)                     AS `amount`,
    `a`.`gmt_create`             AS `gmt_create`,
    `a`.`gmt_modified`           AS `gmt_modified`,
    `a`.`modifier_code`          AS `modifier_code`,
    `a`.`modifier_name`          AS `modifier_name`
  from `whweo`.`pc_product_demand_plan` `a`
  where (`a`.`status_int` = 0)
  group by `a`.`sale_demand_batch_code`;

