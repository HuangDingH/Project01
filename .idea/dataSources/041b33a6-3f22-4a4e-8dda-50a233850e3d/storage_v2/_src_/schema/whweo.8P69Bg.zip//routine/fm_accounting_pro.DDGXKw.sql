create procedure fm_accounting_pro(IN gyear varchar(4), IN gmonth varchar(2), IN fillman varchar(20), OUT gindex int)
  comment '存储过程-原材料存货核算'
  label_pro:BEGIN
	#Routine body goes here...

#定义全局变量
DECLARE sysdate varchar(50); #系统时间
DECLARE nyear varchar(4); #上期的年
DECLARE nmonth varchar(2); #上期的月
DECLARE lastMonthMoney DECIMAL(18,2); #上个月材料明细结存金额
DECLARE lastMonthNum DECIMAL(18,5);  #上个月材料明细结存数量
DECLARE nnum int;
DECLARE num int;
DECLARE ndate varchar(50); #系统上期核算时间
DECLARE TempInt int; #临时变量

#判断并删除临时表
DROP table if exists TempStorageIn;
DROP table if exists TempSubStorageIn;
DROP table if exists TempStorageNotMarid;
DROP table if exists TempReceiveNum;
DROP table if exists TempOutNum;
DROP table if exists TempMaterialCodeDetail;
DROP table if exists TempMaterialCodeInOutDetail;
DROP table if exists TempSubStorageInd;
DROP table if exists TempSubStorageInd1;

#开始事物
START TRANSACTION;

#获取当前系统时间和上期年月
SET sysdate=CONVERT(NOW(),CHAR); 
IF(gmonth=01) THEN
SET nmonth='12';
SET nyear = CONVERT((CONVERT(gyear,SIGNED))-1,CHAR);
ELSE
SET nmonth = CONVERT((CONVERT(gmonth,SIGNED))-1,CHAR);
SET nnum=LENGTH(@nmonth);
IF(nnum=1) THEN
SET nmonth=CONCAT('0',nmonth);
END IF; 
SET nyear=gyear;
END IF;
#select nyear,nmonth;

#SELECT COUNT(*) INTO gindex FROM fm_accounting WHERE `year`=gyear and `month`=gmonth and `accounting_name`=fillman;
#set @gindex=(SELECT COUNT(*) FROM fm_accounting WHERE `year`=gyear and `month`=gmonth and `accounting_name`=fillman);

#获取上期出库核算系统的时间
SET ndate=(SELECT accounting_time from fm_accounting where month=nmonth AND year=nyear);
SET ndate=ifnull(ndate,'');



#================================向核算总表中插入状态:1,核算中=============================

SET TempInt=(select count(*)  FROM  fm_accounting WHERE year=gyear AND month=gmonth);

IF(TempInt=0) THEN
INSERT INTO fm_accounting (year,month,accounting_time,state,accounting_name) VALUES (gyear,gmonth,sysdate,'1',fillman);
ELSE
UPDATE fm_accounting set state='1',accounting_time=sysdate,accounting_name=fillman where year=gyear and month=gmonth;
END IF;

#================================删除本月新增的差额入库单====================

DELETE from sm_storage_detail_in where account_year=gyear and account_month=gmonth and audit_state=3;


#===============更新入库单，领料调拨单，采购发票的核算状态，1表示已核算，区分暂估单据=================

UPDATE fm_purchase_invoice set accounting_state=1 where accounting_year=gyear and accounting_month =gmonth and state=2;
UPDATE sm_storage_detail_in set account_state=1 where account_year=gyear and account_month=gmonth and audit_state=2;
UPDATE sm_storage_change set account_state=1 where account_year=gyear and account_month=gmonth and pick_type=1 and audit_state=2;
#update sm_sale_out set account_state=1,account_time=sysdate where account_year=gyear and account_month=gmonth and audit_state=1;
#update SM_StoreCheck set HeSuanState='1' where HesuanYear=@gyear and hesuanmonth =@gmonth 
#==========================================================================================
 
#建立采购发票对应入库单临时表
#CREATE TEMPORARY TABLE TempStorageIn select * from 
#(select a.checked_time,a.accounting_year,a.accounting_month,ROUND(a.total_money,2) as InvioceMoney,
#b.checked_quatity,ROUND(b.checked_account,2) as StorageInGJMoney,b.receive_quantity,b.material_code,b.batch_code,c.ZhangNum,
#c.Price,c.Units,c.TaxPrice,c.TaxRate,c.TaxMoney,c.QATimeStart,c.QATime,c.QATimeEnd,c.HeadNote,c.Note,c.ManifestNum,
#c.PlanMode,c.SupplierName,c.OrderNum,c.MaterialName,c.Model,c.Textures,c.NationalStandard,c.Sizing,c.SaleMan,
#c.IdentNum,c.RelateOrderId,c.StorageBin,c.GJState,c.GJNum
#from dbo.fm_purchase_invoice as a inner join View_SM_StorageIn as b 
#on b.Guid=c.InfoGuid where a.HesuanYear=gyear and a.hesuanmonth =gmonth
#and a.GJState='1' and c.Color='0')a;




#================================插入本月的跨月勾稽差额入库单====================

#建立跨月勾稽入库单汇总临时表（整合跨月勾稽入库差额单）
#drop table if exists TempStorageIn;
CREATE TEMPORARY TABLE TempStorageIn (SELECT a.warehouse_entry_code,a.demand_plan_code,a.material_code,a.material_name,a.batch_code,a.order_code,a.supplier_name,a.receive_quantity,a.units,b.account,a.tax_rate,a.tax_account,a.account_year,a.account_month,a.checked_year,a.checked_month,a.checked_quantity,a.checked_account,a.checked_state FROM sm_storage_detail_in as a RIGHT OUTER JOIN (SELECT secondary_warehouse_entry_code,material_code,supplier_name,SUM(account) as account FROM sm_storage_detail_in WHERE checked_state<>0 GROUP BY secondary_warehouse_entry_code,material_code,supplier_name) as b ON a.warehouse_entry_code=b.secondary_warehouse_entry_code AND a.material_code=b.material_code AND a.supplier_name=b.supplier_name);

#建立跨月勾稽入库单差额临时表
CREATE TEMPORARY TABLE TempSubStorageIn SELECT warehouse_entry_code,demand_plan_code,material_code,material_name,batch_code,order_code,supplier_name,receive_quantity,units,-(account-checked_account-(receive_quantity-checked_quantity)*(account/receive_quantity))as account1,account,tax_rate,tax_account,((-(account-checked_account-(receive_quantity-checked_quantity)*(account/receive_quantity)))*(1+tax_rate/100)) as tax_account1,account_year,account_month,checked_year,checked_month,checked_quantity,checked_account,checked_state FROM TempStorageIn WHERE (account_month <> checked_month AND account_year=checked_year) or (account_month='12' and checked_month='01' and checked_year-account_year=1);


#插入跨月差额入库单
INSERT INTO sm_storage_detail_in (warehouse_entry_code,demand_plan_code,material_code,material_name,batch_code,order_code,supplier_name,account,tax_rate,tax_account,account_year,account_month,checked_year,checked_month,checked_account,checked_state,account_state,audit_state,audit_time,secondary_warehouse_entry_code) SELECT CONCAT(warehouse_entry_code,'A'),demand_plan_code,material_code,material_name,batch_code,order_code,supplier_name,account1,tax_rate,tax_account1,gyear,gmonth,checked_year,checked_month,checked_account,2,1,3,sysdate,warehouse_entry_code FROM TempSubStorageIn where (checked_year=gyear and checked_month=gmonth);


#建立跨月勾稽入库单差额详情临时表 
CREATE TEMPORARY TABLE TempSubStorageInd SELECT a.*,b.warehouse_in_type,b.store_house_name,b.store_position_name FROM TempSubStorageIn as a LEFT OUTER JOIN sm_storage_in as b ON a.warehouse_entry_code=b.warehouse_entry_code WHERE a.checked_year=gyear and a.checked_month=gmonth;

CREATE TEMPORARY TABLE TempSubStorageInd1 SELECT CONCAT(a.warehouse_entry_code,'A') as warehouse_entry_code,a.warehouse_in_type,a.store_house_name,a.store_position_name,b.warehouse_entry_code AS wec FROM TempSubStorageInd as a LEFT OUTER JOIN sm_storage_in as b ON CONCAT(a.warehouse_entry_code,'A')=b.warehouse_entry_code;

#SELECT * from TempSubStorageInd1;
INSERT INTO sm_storage_in (warehouse_entry_code,warehouse_in_type,store_house_name,store_position_name) SELECT warehouse_entry_code,warehouse_in_type,store_house_name,store_position_name FROM TempSubStorageInd1 WHERE wec is null;

#=====================================更新收发存汇总表=====================================

#清空收发存汇总表本月将要核算的数据
DELETE FROM fm_material_summary WHERE YEAR=gyear and MONTH=gmonth;

#将上月收发存汇总表数据结转至本月
INSERT INTO fm_material_summary (material_code,material_name,specification,texture,national_standard,unit,beginning_price,beginning_quantity,beginning_balance,end_price,end_quantity,end_balance,income_price,income_quantity,income_money,outcome_price,outcome_quantity,outcome_money,isshow,accounting_year,accounting_month,accounting_time) SELECT material_code,material_name,specification,texture,national_standard,unit,end_price,end_quantity,end_balance,end_price,end_quantity,end_balance,0,0,0,0,0,0,0,gyear,gmonth,sysdate FROM fm_material_summary WHERE accounting_year=nyear AND accounting_month=nmonth;

#找出本月入库单和出库单中是否有收发存汇总表里没有的物料编码，如果没有，标记为'1',并存入临时表中（防错处理）
CREATE TEMPORARY TABLE TempStorageNotMarid SELECT *,case when c.id is null then '1' else '0' end as IsExist from (select a.*,b.id from (select distinct material_code FROM (select material_code from sm_storage_detail_in where account_year=gyear and account_month=gmonth union all select material_code from sm_storage_change where account_year=gyear and account_month=gmonth and pick_type=1 and audit_state=2)n)a LEFT OUTER JOIN (select id,material_code as B from fm_material_summary where accounting_year=gyear and accounting_month=gmonth) as b on a.material_code=b.B)c;

#将没有的物料编码插入收发存汇总表
INSERT INTO fm_material_summary (material_code,material_name,specification,unit,beginning_price,beginning_quantity,beginning_balance,end_price,end_quantity,end_balance,income_price,income_quantity,income_money,outcome_price,outcome_quantity,outcome_money,isshow,accounting_year,accounting_month,accounting_time) SELECT a.material_code,b.material_name,b.specification,b.main_unit,0,0,0,0,0,0,0,0,0,0,0,0,0,gyear,gmonth,sysdate FROM TempStorageNotMarid as a LEFT OUTER JOIN bdp_material as b on a.material_code=b.material_code WHERE IsExist=1;

#建立本月入库收入汇总临时表
#drop table if exists TempReceiveNum;
CREATE TEMPORARY TABLE TempReceiveNum SELECT SUM(account) as ReceiveMoney, SUM(receive_quantity) as ReceiveNum, material_code FROM sm_storage_detail_in WHERE account_year=gyear AND account_month=gmonth AND (audit_state =2 or audit_state=3) group by material_code;

#更新收发存汇总表中的本期收入金额，收入数量，收入单价
UPDATE fm_material_summary as a LEFT OUTER JOIN TempReceiveNum as b ON a.material_code=b.material_code SET a.income_price=CASE WHEN IFNULL(b.ReceiveNum,0)=0 THEN 0 ELSE (IFNULL(b.ReceiveMoney,0)/b.ReceiveNum) END, a.income_quantity=IFNULL(b.ReceiveNum,0), a.income_money=IFNULL(b.ReceiveMoney,0) WHERE a.accounting_year=gyear AND a.accounting_month=gmonth;

#更新本月生产领料调拨单单价和金额
#UPDATE sm_storage_change as a LEFT OUTER JOIN  fm_material_summary as b on a.material_code=b.material_code SET a.price=(b.beginning_balance+b.income_money)/(b.beginning_quantity+b.income_quantity), a.account=a.actual_delivery_quantity*(b.beginning_balance+b.income_money)/(b.beginning_quantity+b.income_quantity) WHERE a.account_year=gyear and a.account_month=gmonth and a.pick_type=1 and a.audit_state=2 and b.accounting_year=gyear and b.accounting_month=gmonth;

#更新库存单价
UPDATE sm_store as a LEFT OUTER JOIN fm_material_summary as b on a.material_code=b.material_code and b.accounting_year=gyear and b.accounting_month=gmonth SET a.price=(b.beginning_balance+b.income_money)/(b.beginning_quantity+b.income_quantity); 

#建立本月生产领料汇总临时表
#drop table if exists TempOutNum;
CREATE TEMPORARY TABLE TempOutNum SELECT SUM(actual_delivery_quantity) as OutNum, SUM(account) as OutMoney, material_code FROM sm_storage_change WHERE account_year=gyear and account_month=gmonth and pick_type=1 and audit_state=2 GROUP BY material_code;

#更新收发存汇总表中的本期发出数据和期末数据
#SELECT *, a.beginning_balance+a.income_money-IFNULL(b.OutMoney,0)  FROM fm_material_summary as a LEFT OUTER JOIN TempOutNum as b on a.material_code=b.material_code WHERE a.accounting_year=gyear AND a.accounting_month=gmonth;
UPDATE fm_material_summary as a LEFT OUTER JOIN TempOutNum as b on a.material_code=b.material_code SET a.outcome_price=CASE WHEN IFNULL(b.OutNum,0)=0 THEN 0 ELSE (IFNULL(b.OutMoney,0)/b.OutNum) END, a.outcome_quantity=IFNULL(b.OutNum,0), a.outcome_money=IFNULL(b.OutMoney,0), a.end_price=CASE WHEN (a.beginning_quantity+a.income_quantity-IFNULL(b.OutNum,0))=0 THEN 0 ELSE ((a.beginning_balance+a.income_money-IFNULL(b.OutMoney,0))/(a.beginning_quantity+a.income_quantity-IFNULL(b.OutNum,0))) END, a.end_quantity=a.beginning_quantity+a.income_quantity-IFNULL(b.OutNum,0), a.end_balance=a.beginning_balance+a.income_money-IFNULL(b.OutMoney,0) WHERE a.accounting_year=gyear AND a.accounting_month=gmonth;

#期末数量为0，期末金额不为0的数据置为0
UPDATE fm_material_summary SET end_balance=0 where accounting_month=gmonth and accounting_year=gyear and end_quantity=0 and end_balance<>0;

#删除期初、收入、发出、期末全为0的数据
DELETE FROM fm_material_summary  where accounting_month=gmonth and accounting_year=gyear and beginning_quantity=0 and beginning_balance=0 and income_quantity=0 and income_money=0 and outcome_quantity=0 and outcome_money=0 and end_quantity=0 and end_balance=0;


#==================================更新材料明细表==========================================================
#获取本月出入库单明细账按时间排序
CREATE TEMPORARY TABLE TempMaterialCodeDetail SELECT warehouse_in_type as Type, '0' AS TypeChild,warehouse_entry_code as StorageNum,material_code,material_name,batch_code as batch, specification_model as specification, store_house_name as StoreName, store_position_name as PositionName, units as unit, audit_time as StorageDate, price as InPrice,SUM(IFNULL(receive_quantity,0)) AS InNum, SUM(IFNULL(account,0)) AS InMoney,'0' AS OutPrice,'0' AS OutNum,'0' AS OutMoney FROM view_storage_items WHERE (audit_state =2 or audit_state=3) AND account_year=gyear AND account_month=gmonth GROUP BY warehouse_entry_code,material_code,material_name,batch_code,specification,unit,audit_time UNION SELECT pick_type as Type, '1' AS TypeChild, storage_change_code as StorageNum, material_code, material_name, batch_code, specification_model as specification,store_house_out_name as StoreName, store_position_out_name as PositionName,units as unit, audit_time as StorageDate, '0' AS InPrice,'0' AS InNum,'0' AS InMoney, price as OutPrice,SUM(IFNULL(actual_delivery_quantity,0)) AS OutNum, SUM(IFNULL(account,0)) AS OutMoney FROM sm_storage_change WHERE pick_type=1 AND (audit_state =2 or audit_state=3) and account_year=gyear and account_month=gmonth GROUP BY storage_change_code,material_code,material_name,batch_code,specification,unit,audit_time; 

CREATE TABLE TempMaterialCodeInOutDetail SELECT * FROM (SELECT *, @row:=@row+1, IF(@pjan=base_tmp.material_code, @rank :=@rank+1,@rank :=1) as rownum,@pjan:=base_tmp.material_code FROM (SELECT * FROM TempMaterialCodeDetail ORDER BY material_code,str_to_date(StorageDate,'%Y%m%d %H:%i:%s') ASC)base_tmp,(select  @row :=0 , @puid := null ,@pjan:=null ,@rank:=0)a)n; 

#为了防止出错，删除本月数据
DELETE FROM fm_material_detail where accounting_year=gyear and accounting_month=gmonth;
DELETE FROM fm_material_detail_balance where accounting_year=gyear and accounting_month=gmonth;

#将不包含上月结存的数据存入材料明细表
INSERT INTO fm_material_detail (type,type_child,storage_date,material_code,material_name,storage_code,batch,warehouse,specification,unit,beginning_price,beginning_quantity,beginning_balance,income_price,income_quantity,income_money,outcome_price,outcome_quantity,outcome_money,end_price,end_quantity,end_balance,accounting_year,accounting_month,accounting_time,accounting_state) SELECT a.Type,a.TypeChild,a.StorageDate,a.material_code,a.material_name,a.StorageNum,a.batch,a.StoreName,a.specification,a.unit,'0' as BeginPrice,SUM(IFNULL(b.InNum,0))-SUM(IFNULL(b.OutNum,0)) AS BeginNum ,SUM(IFNULL(b.InMoney,0))-SUM(IFNULL(b.OutMoney,0)) AS BeginMoney,case when a.InNum=0 or a.InNum is null then 0 else a.InMoney/a.InNum end as InPrice,a.InNum,a.InMoney,case when a.OutNum=0 or a.OutNum is null then 0 else a.OutMoney/a.OutNum end as OutPrice,a.OutNum,a.OutMoney,'0' as EndPrice,SUM(IFNULL(b.InNum,0))-SUM(IFNULL(b.OutNum,0))+IFNULL(a.InNum,0)-IFNULL(a.OutNum,0) AS EndNum,SUM(IFNULL(b.InMoney,0))-SUM(IFNULL(b.OutMoney,0))+IFNULL(a.InMoney,0)-IFNULL(a.OutMoney,0) AS EndMoney,gyear,gmonth,sysdate,1 FROM TempMaterialCodeInOutDetail AS a  LEFT OUTER JOIN TempMaterialCodeInOutDetail AS b  ON a.material_code=b.material_code AND a.rownum>b.rownum GROUP BY a.Type,a.TypeChild,a.material_code,a.material_name,a.specification,a.unit,a.StorageNum,a.StorageDate,a.InNum,a.InMoney,a.OutPrice,a.OutNum,a.OutMoney ORDER BY a.material_code,a.StorageDate;

#考虑上月结存，重新计算材料明细表中的数据
UPDATE fm_material_detail as a LEFT OUTER JOIN fm_material_detail_balance as b on a.material_code=b.material_code set a.beginning_quantity=a.beginning_quantity+b.end_quantity,a.beginning_balance=a.beginning_balance+b.end_balance,a.beginning_price=case when (a.beginning_quantity+b.end_quantity)=0 then 0 else (a.beginning_balance+b.end_balance)/(a.beginning_quantity+b.end_quantity) end,a.end_quantity=a.end_quantity+b.end_quantity,a.end_balance=a.end_balance+b.end_balance,a.end_price=case when (a.end_quantity+b.end_quantity)=0 then 0 else (a.end_balance+b.end_balance)/(a.end_quantity+b.end_quantity) end where a.accounting_year=gyear and a.accounting_month=gmonth and b.accounting_year=nyear and b.accounting_month=nmonth;

#更新本月结存
INSERT INTO fm_material_detail_balance ( material_code, material_name, accounting_month, accounting_year, accounting_time, end_quantity, end_balance) select material_code,material_name,gmonth,gyear,sysdate,SUM(end_quantity),SUM(end_balance) from (select material_code, material_name, end_quantity, end_balance from  fm_material_detail_balance where accounting_year=nyear and accounting_month=nmonth union all select material_code,material_name,SUM(IFNULL(income_quantity,0))-SUM(IFNULL(outcome_quantity,0)) as end_quantity,SUM(IFNULL(income_money,0))-SUM(IFNULL(outcome_money,0)) as end_balance from fm_material_detail where accounting_year=gyear and accounting_month=gmonth group by material_code,material_name,specification,unit)a group by material_code,material_name;



#================================向核算总表中插入状态:1,核算中=============================

SET TempInt=(select count(*)  FROM  fm_accounting WHERE year=gyear AND month=gmonth);

IF(TempInt=0) THEN
INSERT INTO fm_accounting (year,month,accounting_time,state,accounting_name) VALUES (gyear,gmonth,sysdate,'1',fillman);
ELSE
UPDATE fm_accounting set state='1',accounting_time=sysdate,accounting_name=fillman where year=gyear and month=gmonth;
END IF;



#=============================检查是否在核算中插入了新的入库单，出库单，发票，如果有，则核算失败============================
#存在未成功核算的入库单
set TempInt=(select count(*) FROM sm_storage_detail_in where account_year=gyear and account_month=gmonth and audit_state=2 and account_state<>1);
if(TempInt>0) THEN
ROLLBACK;
set gindex=1;
drop table if exists TempStorageIn;
drop table if exists TempSubStorageIn;
drop table if exists TempStorageNotMarid;
drop table if exists TempReceiveNum;
drop table if exists TempOutNum;
drop table if exists TempMaterialCodeDetail;
drop table if exists TempMaterialCodeInOutDetail;
drop table if exists TempSubStorageInd;
drop table if exists TempSubStorageInd1;
LEAVE label_pro;
END IF;

#存在未成功核算的领料调拨单
set TempInt=(select count(*) FROM sm_storage_change where account_year=gyear and account_month=gmonth and pick_type=1 and audit_state=2 and account_state<>1);
if(TempInt>0) THEN
ROLLBACK;
set gindex=2;
drop table if exists TempStorageIn;
drop table if exists TempSubStorageIn;
drop table if exists TempStorageNotMarid;
drop table if exists TempReceiveNum;
drop table if exists TempOutNum;
drop table if exists TempMaterialCodeDetail;
drop table if exists TempMaterialCodeInOutDetail;
drop table if exists TempSubStorageInd;
drop table if exists TempSubStorageInd1;
LEAVE label_pro;
END IF;

#存在未成功核算的采购发票
set TempInt=(select count(*) FROM fm_purchase_invoice where accounting_year=gyear and accounting_month =gmonth and state=2 and accounting_state<>1);
if(TempInt>0) THEN
ROLLBACK;
set gindex=3;
drop table if exists TempStorageIn;
drop table if exists TempSubStorageIn;
drop table if exists TempStorageNotMarid;
drop table if exists TempReceiveNum;
drop table if exists TempOutNum;
drop table if exists TempMaterialCodeDetail;
drop table if exists TempMaterialCodeInOutDetail;
drop table if exists TempSubStorageInd;
drop table if exists TempSubStorageInd1;
LEAVE label_pro;
END IF;

#账期内存在未审核的采购发票
set TempInt=(select count(*) FROM fm_purchase_invoice where accounting_year=gyear and accounting_month =gmonth and state<>2);
if(TempInt > 0) THEN
#INSERT INTO sm_storage_detail_in SET warehouse_entry_code=2211;
ROLLBACK;
set gindex=4;
drop table if exists TempStorageIn;
drop table if exists TempSubStorageIn;
drop table if exists TempStorageNotMarid;
drop table if exists TempReceiveNum;
drop table if exists TempOutNum;
drop table if exists TempMaterialCodeDetail;
drop table if exists TempMaterialCodeInOutDetail;
drop table if exists TempSubStorageInd;
drop table if exists TempSubStorageInd1;
LEAVE label_pro;
END IF;

drop table if exists TempStorageIn;
drop table if exists TempSubStorageIn;
drop table if exists TempStorageNotMarid;
drop table if exists TempReceiveNum;
drop table if exists TempOutNum;
drop table if exists TempMaterialCodeDetail;
drop table if exists TempMaterialCodeInOutDetail;
drop table if exists TempSubStorageInd;
drop table if exists TempSubStorageInd1;

COMMIT;
set gindex=0;
END;

