create view view_pc_bom_details as
  select
    `a`.`id`                   AS `id`,
    `a`.`material_code`        AS `material_code`,
    `a`.`material_name`        AS `material_name`,
    `a`.`yield`                AS `yield`,
    `b`.`amount`               AS `base_amount`,
    `c`.`id`                   AS `bom_id`,
    `c`.`version`              AS `bom_version`,
    `d`.`material_code`        AS `part_material_code`,
    `d`.`material_name`        AS `part_material_name`,
    `d`.`material_attribute`   AS `material_attribute`,
    `d`.`main_unit`            AS `unit`,
    `d`.`specification`        AS `specification`,
    `d`.`serial_code`          AS `serial_code`,
    `d`.`group_name`           AS `group_name`,
    `d`.`production_lead_time` AS `production_lead_time`
  from (((`whweo`.`bdp_bom` `a` left join `whweo`.`bdp_bom_material` `b` on ((`a`.`id` = `b`.`bom_id`))) left join
    `whweo`.`bdp_bom` `c` on (((`c`.`material_code` = `b`.`material_code`) and (`c`.`is_default` = 1)))) left join
    `whweo`.`bdp_material` `d` on ((`b`.`material_code` = `d`.`material_code`)))
  where (`a`.`is_default` = 1);

