create view view_qc_final_uncheck_turnover as
  select
    `u`.`production_batch_code` AS `production_batch_code`,
    `u`.`turnover_batch_code`   AS `turnover_batch_code`,
    `t`.`material_code`         AS `material_code`,
    `t`.`material_name`         AS `material_name`,
    `u`.`gmt_create`            AS `gmt_create`
  from (`whweo`.`qc_final_uncheck_turnover` `u` left join `whweo`.`ex_turnover_batch_code` `t`
      on ((`u`.`turnover_batch_code` = `t`.`turnover_batch_code`)));

