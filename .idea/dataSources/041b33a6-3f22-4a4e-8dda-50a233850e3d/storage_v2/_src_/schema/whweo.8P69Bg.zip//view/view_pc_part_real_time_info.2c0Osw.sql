create view view_pc_part_real_time_info as
  select
    `a`.`id`                                                                                         AS `id`,
    `m`.`material_code`                                                                              AS `material_code`,
    `m`.`material_name`                                                                              AS `material_name`,
    `m`.`specification`                                                                              AS `specification`,
    `m`.`serial_code`                                                                                AS `serial_code`,
    ifnull(date_format(`a`.`beginning_time`, '%Y-%m-%d %H:%i:%s'),
           '0000-00-00 00:00:00')                                                                    AS `beginning_time`,
    ifnull(`a`.`beginning_demand_amount`,
           0)                                                                                        AS `beginning_demand_amount`,
    ifnull(`d`.`add_demand_amount`,
           0)                                                                                        AS `add_demand_amount`,
    ifnull(`c`.`outbound_amount`,
           0)                                                                                        AS `outbound_amount`,
    ifnull(((`a`.`beginning_demand_amount` + `d`.`add_demand_amount`) - `c`.`outbound_amount`),
           0)                                                                                        AS `real_time_demand_amount`,
    ifnull(`a`.`beginning_stock_amount`,
           0)                                                                                        AS `beginning_stock_amount`,
    ifnull(`b`.`real_time_stock_amount`,
           0)                                                                                        AS `real_time_stock_amount`,
    ifnull(`a`.`beginning_plan_amount`,
           0)                                                                                        AS `beginning_plan_amount`,
    ifnull(`e`.`add_production_amount`,
           0)                                                                                        AS `add_production_amount`,
    ifnull(`f`.`produced_amount`,
           0)                                                                                        AS `produced_amount`,
    ifnull(((`a`.`beginning_plan_amount` + `e`.`add_production_amount`) - `f`.`produced_amount`),
           0)                                                                                        AS `real_time_plan_amount`
  from ((((((`whweo`.`bdp_material` `m` left join `whweo`.`pc_part_beginning_info` `a`
      on ((`m`.`material_code` = `a`.`material_code`))) left join `whweo`.`view_pc_real_time_stock` `b`
      on ((`a`.`material_code` = `b`.`material_code`))) left join `whweo`.`view_pc_part_real_time_outbound` `c`
      on ((`a`.`id` = `c`.`id`))) left join `whweo`.`view_pc_part_real_time_add_demand` `d`
      on ((`a`.`id` = `d`.`id`))) left join `whweo`.`view_pc_part_real_time_add_production` `e`
      on ((`a`.`id` = `e`.`id`))) left join `whweo`.`view_pc_part_real_time_produced` `f` on ((`a`.`id` = `f`.`id`)))
  where (not ((`m`.`material_code` like '41%')));

