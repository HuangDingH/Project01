create view view_bom as
  select
    `b`.`id`            AS `id`,
    `b`.`code`          AS `code`,
    `b`.`name`          AS `name`,
    `b`.`version`       AS `version`,
    `b`.`is_default`    AS `is_default`,
    `b`.`is_confirm`    AS `is_confirm`,
    `b`.`material_name` AS `material_name`,
    `b`.`material_code` AS `material_code`,
    `b`.`is_rework`     AS `is_rework`,
    `m`.`serial_code`   AS `serial_code`,
    `m`.`specification` AS `specification`,
    `b`.`fixed_loss`    AS `fixed_loss`,
    `m`.`main_unit`     AS `main_unit`,
    `b`.`yield`         AS `yield`,
    `t`.`name`          AS `process_route_template_name`,
    `t`.`id`            AS `process_route_template_id`,
    `t`.`code`          AS `process_route_template_code`,
    `b`.`modifier_code` AS `modifier_code`,
    `b`.`modifier_name` AS `modifier_name`,
    `b`.`gmt_modified`  AS `gmt_modified`,
    `b`.`gmt_create`    AS `gmt_create`
  from ((`whweo`.`bdp_bom` `b` left join `whweo`.`bdp_material` `m`
      on ((`b`.`material_code` = `m`.`material_code`))) left join `whweo`.`bdp_processroute_template` `t`
      on ((`b`.`process_route_template_id` = `t`.`id`)));

