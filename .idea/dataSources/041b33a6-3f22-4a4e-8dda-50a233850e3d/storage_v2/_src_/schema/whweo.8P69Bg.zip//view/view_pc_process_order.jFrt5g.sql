create view view_pc_process_order as
  select
    `a`.`id`                         AS `id`,
    `a`.`production_order_id`        AS `production_order_id`,
    `a`.`production_order_code`      AS `production_order_code`,
    `a`.`production_batch_code`      AS `production_batch_code`,
    `a`.`material_code`              AS `material_code`,
    `a`.`material_name`              AS `material_name`,
    `a`.`bom_id`                     AS `bom_id`,
    `a`.`process_id`                 AS `process_id`,
    `a`.`process_code`               AS `process_code`,
    `a`.`process_name`               AS `process_name`,
    `a`.`after_code`                 AS `after_code`,
    `a`.`output_material_status_str` AS `output_material_status_str`,
    `a`.`good_amount`                AS `good_amount`,
    `a`.`bad_amount`                 AS `bad_amount`,
    `a`.`bad_process_amount`         AS `bad_process_amount`,
    `a`.`bad_material_amount`        AS `bad_material_amount`,
    sum(`d`.`production_amount`)     AS `target_amount`,
    `a`.`state_type`                 AS `state_type`,
    `a`.`state_name`                 AS `state_name`,
    `a`.`order_state_start_time`     AS `order_state_start_time`,
    `a`.`plan_start_time`            AS `plan_start_time`,
    `a`.`plan_end_time`              AS `plan_end_time`,
    `a`.`actual_start_time`          AS `actual_start_time`,
    `a`.`actual_end_time`            AS `actual_end_time`,
    `b`.`work_center_id`             AS `work_center_id`,
    `b`.`work_center_name`           AS `work_center_name`
  from ((`whweo`.`pc_process_order` `a` left join `whweo`.`pc_production_daily_plan` `d`
      on ((`a`.`production_order_id` = `d`.`production_order_id`))) left join `whweo`.`ex_process_order_work_center` `b`
      on ((`a`.`id` = `b`.`process_order_id`)))
  group by `a`.`id`, `b`.`work_center_id`;

