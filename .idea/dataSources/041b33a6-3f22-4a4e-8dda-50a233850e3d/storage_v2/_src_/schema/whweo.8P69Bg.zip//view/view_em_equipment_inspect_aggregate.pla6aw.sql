create view view_em_equipment_inspect_aggregate as
  select
    `p`.`year_identify`                                                      AS `year_identify`,
    `p`.`equipment_id`                                                       AS `equipment_id`,
    `p`.`equipment_code`                                                     AS `equipment_code`,
    `p`.`equipment_name`                                                     AS `equipment_name`,
    `p`.`maintain_responsible_person`                                        AS `maintain_responsible_person`,
    `p`.`person_code`                                                        AS `person_code`,
    `p`.`month_identify`                                                     AS `month_identify`,
    replace(group_concat(`p`.`inspect_type_name` separator ','), ',', '   ') AS `inspect_type_name`
  from `whweo`.`em_equipment_inspect` `p`
  group by `p`.`year_identify`, `p`.`equipment_code`, `p`.`month_identify`;

