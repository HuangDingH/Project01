create view view_pc_part_real_time_add_production as
  select
    `a`.`id`                                AS `id`,
    `a`.`material_code`                     AS `material_code`,
    ifnull(sum(`b`.`production_amount`), 0) AS `add_production_amount`
  from ((`whweo`.`pc_part_beginning_info` `a` left join `whweo`.`view_pc_part_real_time_maxtime` `c`
      on ((`a`.`material_code` = `c`.`material_code`))) left join `whweo`.`pc_production_daily_plan` `b`
      on (((`a`.`material_code` = `b`.`material_code`) and
           (str_to_date(`b`.`gmt_create`, '%Y-%m-%d %H:%i:%s') > `c`.`max_beginning_time`))))
  group by `a`.`material_code`;

