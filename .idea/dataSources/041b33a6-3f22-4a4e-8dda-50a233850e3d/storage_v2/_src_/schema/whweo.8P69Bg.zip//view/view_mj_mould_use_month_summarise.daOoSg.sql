create view view_mj_mould_use_month_summarise as
  select
    `p`.`month_identify`                                                 AS `month_identify`,
    `p`.`mould_code`                                                     AS `mould_code`,
    `p`.`material_code`                                                  AS `material_code`,
    `p`.`material_name`                                                  AS `material_name`,
    `p`.`unit`                                                           AS `unit`,
    `p`.`rated_modulus`                                                  AS `rated_modulus`,
    `p`.`full_cavity_amount`                                             AS `full_cavity_amount`,
    round(avg(`p`.`real_cavity_amount`), 2)                              AS `average_real_cavity_amount`,
    round(avg(`p`.`cavity_use_rate`), 4)                                 AS `average_cavity_use_rate`,
    sum(`p`.`real_modulus`)                                              AS `real_modulus`,
    sum(`p`.`real_cavity_output`)                                        AS `real_cavity_amount`,
    sum(`p`.`output_amount`)                                             AS `output_amount`,
    round((sum(`p`.`real_cavity_output`) / sum(`p`.`output_amount`)), 4) AS `product_qualified_rate`
  from `whweo`.`mj_mould_use` `p`
  group by `p`.`month_identify`, `p`.`mould_code`;

