create view view_pc_production_daily_plan_sum as
  select
    `a`.`material_code`                     AS `material_code`,
    `a`.`material_name`                     AS `material_name`,
    `a`.`start_time`                        AS `start_time`,
    `a`.`end_time`                          AS `end_time`,
    ifnull(sum(`a`.`production_amount`), 0) AS `production_amount_sum`
  from `whweo`.`pc_production_daily_plan` `a`
  group by `a`.`material_code`, `a`.`start_time`;

