create view view_qc_check_material_sum as
  select
    `details`.`material_code`     AS `material_code`,
    `details`.`material_name`     AS `material_name`,
    sum(`details`.`check_result`) AS `bad_amount`,
    sum(`details`.`check_amount`) AS `total_amount`,
    `details`.`work_shop_id`      AS `work_shop_id`,
    `details`.`gmt_create`        AS `check_time`,
    `details`.`check_year`        AS `check_year`,
    `details`.`check_month`       AS `check_month`,
    `details`.`check_day`         AS `check_day`
  from `whweo`.`ex_check_process_details` `details`
  group by `details`.`work_shop_id`, `details`.`check_year`, `details`.`check_month`, `details`.`check_day`,
    `details`.`material_code`;

