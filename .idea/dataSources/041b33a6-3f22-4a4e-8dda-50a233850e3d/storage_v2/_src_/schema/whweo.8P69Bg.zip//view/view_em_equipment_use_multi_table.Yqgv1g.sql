create view view_em_equipment_use_multi_table as
  select
    `a`.`production_batch_code` AS `output_production_batch_code`,
    `a`.`material_name`         AS `output_name`,
    `a`.`process_id`            AS `procrss_id`,
    `a`.`process_name`          AS `correspond_process`,
    `b`.`mould_code`            AS `mould_code`,
    `b`.`efficiency`            AS `productivity`,
    `b`.`efficiency_unit`       AS `productivity_unit`
  from (`whweo`.`pc_process_order` `a` left join `whweo`.`ex_process_order_work_center` `b`
      on ((`a`.`id` = `b`.`process_order_id`)));

