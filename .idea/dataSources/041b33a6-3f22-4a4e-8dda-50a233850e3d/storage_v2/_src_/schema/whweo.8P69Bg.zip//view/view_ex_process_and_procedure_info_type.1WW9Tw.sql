create view view_ex_process_and_procedure_info_type as
  select
    `m`.`process_id`    AS `process_id`,
    `m`.`info_type_id`  AS `info_type_id`,
    `t`.`info_type`     AS `info_type`,
    `m`.`gmt_create`    AS `gmt_create`,
    `m`.`gmt_modified`  AS `gmt_modified`,
    `m`.`modifier_code` AS `modifier_code`,
    `m`.`modifier_name` AS `modifier_name`
  from (`whweo`.`ex_process_and_procedure_info_type` `m` left join `whweo`.`ex_procedure_info_type` `t`
      on ((`m`.`info_type_id` = `t`.`id`)));

