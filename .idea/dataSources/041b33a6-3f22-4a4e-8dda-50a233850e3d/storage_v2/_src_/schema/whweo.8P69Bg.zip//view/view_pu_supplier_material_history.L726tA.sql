create view view_pu_supplier_material_history as
  select
    `a`.`supplier_code` AS `supplier_code`,
    `b`.`material_code` AS `material_code`,
    `c`.`material_name` AS `material_name`,
    `c`.`specification` AS `specification`,
    `b`.`version`       AS `version`,
    `b`.`status`        AS `status`
  from ((`whweo`.`pu_supplier_history` `a`
    join `whweo`.`pu_supplier_material_history` `b` on ((`a`.`supplier_code` = `b`.`supplier_code`))) join
    `whweo`.`bdp_material` `c` on ((`b`.`material_code` = `c`.`material_code`)));

