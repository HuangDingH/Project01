create view view_bom_material as
  select
    `bm`.`id`             AS `id`,
    `bm`.`bom_id`         AS `bom_id`,
    `bom`.`material_code` AS `bom_material_code`,
    `bm`.`material_code`  AS `material_code`,
    `bm`.`amount`         AS `amount`,
    `bm`.`process_id`     AS `process_id`,
    `p`.`process_name`    AS `process_name`,
    `m`.`main_unit`       AS `main_unit`,
    `m`.`material_name`   AS `material_name`,
    `m`.`serial_code`     AS `serial_code`,
    `m`.`specification`   AS `specification`,
    (case `m`.`material_attribute`
     when 0
       then '采购件'
     when 1
       then '自制件'
     else '' end)         AS `material_attribute`
  from (((`whweo`.`bdp_bom_material` `bm` left join `whweo`.`bdp_material` `m`
      on ((`bm`.`material_code` = `m`.`material_code`))) left join `whweo`.`bdp_bom` `bom`
      on ((`bm`.`bom_id` = `bom`.`id`))) left join `whweo`.`bdp_process` `p` on ((`bm`.`process_id` = `p`.`id`)));

