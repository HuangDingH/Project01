create view view_pc_product_real_time_outbound as
  select
    `a`.`id`                                  AS `id`,
    `a`.`material_code`                       AS `material_code`,
    ifnull(sum(`b`.`number_of_shipments`), 0) AS `outbound_amount`
  from ((`whweo`.`pc_product_beginning_info` `a` left join `whweo`.`view_pc_product_real_time_maxtime` `c`
      on ((`a`.`material_code` = `c`.`material_code`))) left join `whweo`.`mm_sale_outbound_order` `b`
      on (((`a`.`material_code` = `b`.`product_code`) and (`b`.`product_outbound_time` > `c`.`max_beginning_time`))))
  group by `a`.`material_code`;

