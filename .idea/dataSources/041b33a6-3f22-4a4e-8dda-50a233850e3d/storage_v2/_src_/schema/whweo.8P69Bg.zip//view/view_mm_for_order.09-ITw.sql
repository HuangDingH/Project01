create view view_mm_for_order as
  select
    `a`.`id`                     AS `id`,
    `a`.`company_code`           AS `company_code`,
    `a`.`company_name`           AS `company_name`,
    `a`.`detailed_address`       AS `detailed_address`,
    `a`.`complete_address`       AS `complete_address`,
    `a`.`link_man_name`          AS `link_man_name`,
    `a`.`link_man_tel`           AS `link_man_tel`,
    `b`.`contract_code`          AS `contract_code`,
    `b`.`contract_type`          AS `contract_type`,
    `b`.`settlement_way`         AS `settlement_way`,
    `b`.`contract_credit_period` AS `contract_credit_period`,
    `b`.`month_settlement_date`  AS `month_settlement_date`,
    `b`.`contract_clear_date`    AS `contract_clear_date`,
    `b`.`shipping_way`           AS `shipping_way`,
    `b`.`fare_undertake_way`     AS `fare_undertake_way`,
    `b`.`is_use`                 AS `is_use`,
    `b`.`is_in_blacklist`        AS `is_in_blacklist`
  from (`whweo`.`mm_customer_address_maintain` `a`
    join `whweo`.`mm_purchase_sale_contract` `b` on ((`a`.`company_code` = `b`.`company_code`)))
  where (`b`.`is_use` = 1);

