create view view_pc_production_order as
  select
    `a`.`id`                                AS `id`,
    `a`.`production_order_code`             AS `production_order_code`,
    `a`.`production_batch_code`             AS `production_batch_code`,
    `a`.`order_status_int`                  AS `order_status_int`,
    `a`.`order_status_str`                  AS `order_status_str`,
    `a`.`status_start_time`                 AS `status_start_time`,
    `a`.`order_type`                        AS `order_type`,
    `a`.`material_code`                     AS `material_code`,
    `a`.`material_name`                     AS `material_name`,
    `a`.`priority`                          AS `priority`,
    min(`b`.`start_time`)                   AS `order_plan_start_time`,
    max(`b`.`end_time`)                     AS `order_plan_end_time`,
    `a`.`order_actual_start_time`           AS `order_actual_start_time`,
    `a`.`order_actual_end_time`             AS `order_actual_end_time`,
    `a`.`bom_id`                            AS `bom_id`,
    `a`.`work_center_id`                    AS `work_center_id`,
    ifnull(sum(`b`.`production_amount`), 0) AS `order_target_amount`,
    ifnull(`d`.`good_amount`, 0)            AS `order_good_amount`,
    ifnull(`d`.`bad_amount`, 0)             AS `order_bad_amount`,
    ifnull(`e`.`rework_amount`, 0)          AS `rework_amount`,
    `a`.`gmt_create`                        AS `gmt_create`,
    `a`.`gmt_modified`                      AS `gmt_modified`,
    `a`.`modifier_code`                     AS `modifier_code`,
    `a`.`modifier_name`                     AS `modifier_name`
  from ((((`whweo`.`pc_production_order` `a` left join `whweo`.`pc_production_daily_plan` `b`
      on ((`a`.`id` = `b`.`production_order_id`))) left join `whweo`.`ex_turnover_batch_code` `c`
      on (((`a`.`production_order_code` = `c`.`production_order_code`) and (`c`.`state_type` = 4)))) left join
    `whweo`.`pc_process_order` `d`
      on (((`a`.`production_order_code` = `d`.`production_order_code`) and (`d`.`after_code` = '')))) left join
    `whweo`.`qc_rework_order` `e` on ((`a`.`production_batch_code` = `e`.`production_batch_code`)))
  group by `a`.`id`, `a`.`material_code`;

