create view view_store_house_position as
  select
    `a`.`id`                  AS `id`,
    `a`.`store_position_code` AS `store_position_code`,
    `a`.`store_position_name` AS `store_position_name`,
    `a`.`parent_id`           AS `parent_id`,
    `b`.`store_house_name`    AS `parent_name`,
    `a`.`note`                AS `note`,
    `a`.`gmt_create`          AS `gmt_create`,
    `a`.`modifier_code`       AS `modifier_code`,
    `a`.`modifier_name`       AS `modifier_name`,
    `a`.`gmt_modified`        AS `gmt_modified`
  from (`whweo`.`sm_store_position` `a` left join `whweo`.`sm_store_house` `b` on ((`a`.`parent_id` = `b`.`id`)));

