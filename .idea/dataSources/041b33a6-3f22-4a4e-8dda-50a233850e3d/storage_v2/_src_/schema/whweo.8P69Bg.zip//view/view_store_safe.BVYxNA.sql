create view view_store_safe as
  select
    `a`.`id`                                                               AS `id`,
    `a`.`material_code`                                                    AS `material_code`,
    `a`.`material_name`                                                    AS `material_name`,
    `a`.`units`                                                            AS `units`,
    `a`.`specification`                                                    AS `specification`,
    `a`.`serial_number`                                                    AS `serial_number`,
    `a`.`safety_amount`                                                    AS `safety_amount`,
    `a`.`modifier_code`                                                    AS `modifier_code`,
    `a`.`modifier_name`                                                    AS `modifier_name`,
    `a`.`gmt_modified`                                                     AS `gmt_modified`,
    ifnull(sum(`b`.`inventory_quantity`), 0)                               AS `inventory_quantity`,
    ifnull(sum(`c`.`demand_amount`), 0)                                    AS `demand_amount`,
    (ifnull(`b`.`inventory_quantity`, 0) - ifnull(`c`.`demand_amount`, 0)) AS `instant_amount`
  from ((`whweo`.`sm_store_safe` `a` left join `whweo`.`sm_store` `b`
      on (((`a`.`material_code` = `b`.`material_code`) and
           ((`b`.`store_house_id` = 2) or (`b`.`store_house_id` = 3) or (`b`.`store_house_id` = 5))))) left join
    `whweo`.`pc_demand_daily_plan` `c`
      on (((`a`.`material_code` = `c`.`material_code`) and (`c`.`predict_demand_time` <= (curdate() + interval 5 day))
           and (`c`.`predict_demand_time` >= curdate()))))
  group by `a`.`material_code`;

