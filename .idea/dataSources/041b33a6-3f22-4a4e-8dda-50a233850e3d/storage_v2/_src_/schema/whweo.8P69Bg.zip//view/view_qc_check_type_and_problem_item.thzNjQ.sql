create view view_qc_check_type_and_problem_item as
  select
    `a`.`id`              AS `id`,
    `a`.`check_type_id`   AS `check_type_id`,
    `a`.`problem_item_id` AS `problem_item_id`,
    `a`.`check_place`     AS `check_place`,
    `a`.`gmt_create`      AS `gmt_create`,
    `a`.`gmt_modified`    AS `gmt_modified`,
    `a`.`modifier_code`   AS `modifier_code`,
    `a`.`modifier_name`   AS `modifier_name`,
    `b`.`item_code`       AS `item_code`,
    `b`.`item_name`       AS `item_name`
  from (`whweo`.`qc_check_type_and_problem_item` `a` left join `whweo`.`qc_check_problem_item` `b`
      on ((`a`.`problem_item_id` = `b`.`id`)));

